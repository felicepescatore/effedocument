<!-- Applicazione:eFFe Document-->
<!-- Versione: 1.0.0.0 - Licenza GPL-->
<!-- Data Rilascio: 02 Febbraio 2010-->
<!-- Developer: ing. Felice Pescatore-->

<style type="text/css">
<!--
.Stile1 {
	font-size: 12px
}
-->
</style>

<p>&nbsp;</p>
<p align="center"><a href="http://www.felicepescatore.it" target="_blank"><img src="../../common/images/loghi/logofp.png" alt="ing. Felice Pescatore"border="0" /></a></p>
<p align="center"><span class="Stile1">versione 1.0.0</span></p>
