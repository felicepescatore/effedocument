<html xmlns:v="urn:schemas-microsoft-com:vml"
xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:w="urn:schemas-microsoft-com:office:word"
xmlns:m="http://schemas.microsoft.com/office/2004/12/omml"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<meta name=ProgId content=Word.Document>
<meta name=Generator content="Microsoft Word 12">
<meta name=Originator content="Microsoft Word 12">
<link rel=File-List href="effedoc_file/filelist.xml">
<link rel=Edit-Time-Data href="effedoc_file/editdata.mso">
<!--[if !mso]>
<style>
v\:* {behavior:url(#default#VML);}
o\:* {behavior:url(#default#VML);}
w\:* {behavior:url(#default#VML);}
.shape {behavior:url(#default#VML);}
</style>
<![endif]-->
<title>eFFe Document</title>
<link rel=themeData href="effedoc_file/themedata.thmx">
<link rel=colorSchemeMapping href="effedoc_file/colorschememapping.xml">
<!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:TrackMoves>false</w:TrackMoves>
  <w:TrackFormatting/>
  <w:HyphenationZone>14</w:HyphenationZone>
  <w:ValidateAgainstSchemas/>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:DoNotPromoteQF/>
  <w:LidThemeOther>IT</w:LidThemeOther>
  <w:LidThemeAsian>X-NONE</w:LidThemeAsian>
  <w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>
  <w:Compatibility>
   <w:BreakWrappedTables/>
   <w:SnapToGridInCell/>
   <w:WrapTextWithPunct/>
   <w:UseAsianBreakRules/>
   <w:DontGrowAutofit/>
   <w:SplitPgBreakAndParaMark/>
   <w:DontVertAlignCellWithSp/>
   <w:DontBreakConstrainedForcedTables/>
   <w:DontVertAlignInTxbx/>
   <w:Word11KerningPairs/>
   <w:CachedColBalance/>
  </w:Compatibility>
  <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel>
  <m:mathPr>
   <m:mathFont m:val="Cambria Math"/>
   <m:brkBin m:val="before"/>
   <m:brkBinSub m:val="&#45;-"/>
   <m:smallFrac m:val="off"/>
   <m:dispDef/>
   <m:lMargin m:val="0"/>
   <m:rMargin m:val="0"/>
   <m:defJc m:val="centerGroup"/>
   <m:wrapIndent m:val="1440"/>
   <m:intLim m:val="subSup"/>
   <m:naryLim m:val="undOvr"/>
  </m:mathPr></w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" DefUnhideWhenUsed="true"
  DefSemiHidden="true" DefQFormat="false" DefPriority="99"
  LatentStyleCount="267">
  <w:LsdException Locked="false" Priority="0" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Normal"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="heading 1"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="heading 2"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="heading 3"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="heading 4"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="heading 5"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="heading 6"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="heading 7"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="heading 8"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="heading 9"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 1"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 2"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 3"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 4"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 5"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 6"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 7"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 8"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 9"/>
  <w:LsdException Locked="false" Priority="35" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="caption"/>
  <w:LsdException Locked="false" Priority="10" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Title"/>
  <w:LsdException Locked="false" Priority="1" Name="Default Paragraph Font"/>
  <w:LsdException Locked="false" Priority="11" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Subtitle"/>
  <w:LsdException Locked="false" Priority="22" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Strong"/>
  <w:LsdException Locked="false" Priority="20" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Emphasis"/>
  <w:LsdException Locked="false" Priority="59" SemiHidden="false"
   UnhideWhenUsed="false" Name="Table Grid"/>
  <w:LsdException Locked="false" UnhideWhenUsed="false" Name="Placeholder Text"/>
  <w:LsdException Locked="false" Priority="1" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="No Spacing"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 1"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 1"/>
  <w:LsdException Locked="false" UnhideWhenUsed="false" Name="Revision"/>
  <w:LsdException Locked="false" Priority="34" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="List Paragraph"/>
  <w:LsdException Locked="false" Priority="29" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Quote"/>
  <w:LsdException Locked="false" Priority="30" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Intense Quote"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 1"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 1"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 1"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 2"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 2"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 2"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 2"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 3"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 3"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 3"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 3"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 4"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 4"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 4"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 4"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 5"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 5"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 5"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 5"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 6"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 6"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 6"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 6"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="19" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Subtle Emphasis"/>
  <w:LsdException Locked="false" Priority="21" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Intense Emphasis"/>
  <w:LsdException Locked="false" Priority="31" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Subtle Reference"/>
  <w:LsdException Locked="false" Priority="32" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Intense Reference"/>
  <w:LsdException Locked="false" Priority="33" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Book Title"/>
  <w:LsdException Locked="false" Priority="37" Name="Bibliography"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="TOC Heading"/>
 </w:LatentStyles>
</xml><![endif]-->
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:Wingdings;
	panose-1:5 0 0 0 0 0 0 0 0 0;
	mso-font-charset:2;
	mso-generic-font-family:auto;
	mso-font-pitch:variable;
	mso-font-signature:0 268435456 0 0 -2147483648 0;}
@font-face
	{font-family:"Cambria Math";
	panose-1:2 4 5 3 5 4 6 3 2 4;
	mso-font-charset:1;
	mso-generic-font-family:roman;
	mso-font-format:other;
	mso-font-pitch:variable;
	mso-font-signature:0 0 0 0 0 0;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;
	mso-font-charset:0;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:-520081665 -1073717157 41 0 66047 0;}
@font-face
	{font-family:Perpetua;
	panose-1:2 2 5 2 6 4 1 2 3 3;
	mso-font-charset:0;
	mso-generic-font-family:roman;
	mso-font-pitch:variable;
	mso-font-signature:3 0 0 0 1 0;}
@font-face
	{font-family:"Franklin Gothic Book";
	panose-1:2 11 5 3 2 1 2 2 2 4;
	mso-font-charset:0;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:647 0 0 0 159 0;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-parent:"";
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:0cm;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:black;}
h1
	{mso-style-priority:9;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-link:"Titolo 1 Carattere";
	margin-top:15.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	mso-pagination:widow-orphan;
	mso-outline-level:1;
	font-size:14.0pt;
	font-family:"Franklin Gothic Book","sans-serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	color:#9D3511;
	letter-spacing:1.0pt;}
h2
	{mso-style-priority:9;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-link:"Titolo 2 Carattere";
	margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	mso-pagination:widow-orphan;
	mso-outline-level:2;
	font-size:12.0pt;
	font-family:"Franklin Gothic Book","sans-serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	color:#9D3511;
	letter-spacing:1.0pt;}
h3
	{mso-style-priority:9;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-link:"Titolo 3 Carattere";
	margin-top:10.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	mso-pagination:widow-orphan;
	mso-outline-level:3;
	font-size:12.0pt;
	font-family:"Franklin Gothic Book","sans-serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	color:#D34817;
	letter-spacing:1.0pt;}
h4
	{mso-style-priority:9;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-link:"Titolo 4 Carattere";
	margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:0cm;
	margin-bottom:.0001pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	mso-outline-level:4;
	font-size:12.0pt;
	font-family:"Franklin Gothic Book","sans-serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	color:#7B6A4D;
	letter-spacing:1.0pt;}
h5
	{mso-style-priority:9;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-link:"Titolo 5 Carattere";
	margin-top:10.0pt;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:0cm;
	margin-bottom:.0001pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	mso-outline-level:5;
	font-size:11.0pt;
	font-family:"Franklin Gothic Book","sans-serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	color:#7B6A4D;
	letter-spacing:1.0pt;
	font-style:italic;}
h6
	{mso-style-priority:9;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-link:"Titolo 6 Carattere";
	margin-top:10.0pt;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:0cm;
	margin-bottom:.0001pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	mso-outline-level:6;
	font-size:12.0pt;
	font-family:"Franklin Gothic Book","sans-serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	color:#524633;
	letter-spacing:.5pt;
	font-weight:normal;}
p.MsoHeading7, li.MsoHeading7, div.MsoHeading7
	{mso-style-priority:9;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-link:"Titolo 7 Carattere";
	margin-top:10.0pt;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:0cm;
	margin-bottom:.0001pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	mso-outline-level:7;
	font-size:12.0pt;
	font-family:"Franklin Gothic Book","sans-serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:#524633;
	letter-spacing:.5pt;
	font-style:italic;}
p.MsoHeading8, li.MsoHeading8, div.MsoHeading8
	{mso-style-priority:9;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-link:"Titolo 8 Carattere";
	margin-top:10.0pt;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:0cm;
	margin-bottom:.0001pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	mso-outline-level:8;
	font-size:11.0pt;
	font-family:"Franklin Gothic Book","sans-serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:#D34817;
	letter-spacing:.5pt;}
p.MsoHeading9, li.MsoHeading9, div.MsoHeading9
	{mso-style-priority:9;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-link:"Titolo 9 Carattere";
	margin-top:10.0pt;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:0cm;
	margin-bottom:.0001pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	mso-outline-level:9;
	font-size:11.0pt;
	font-family:"Franklin Gothic Book","sans-serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:#D34817;
	letter-spacing:.5pt;
	font-style:italic;}
p.MsoToc1, li.MsoToc1, div.MsoToc1
	{mso-style-update:auto;
	mso-style-noshow:yes;
	mso-style-priority:39;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	font-variant:small-caps;
	color:#9B2D1F;}
p.MsoToc2, li.MsoToc2, div.MsoToc2
	{mso-style-update:auto;
	mso-style-noshow:yes;
	mso-style-priority:39;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:10.8pt;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	font-variant:small-caps;
	color:black;}
p.MsoToc3, li.MsoToc3, div.MsoToc3
	{mso-style-update:auto;
	mso-style-noshow:yes;
	mso-style-priority:39;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:22.3pt;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	font-variant:small-caps;
	color:black;}
p.MsoToc4, li.MsoToc4, div.MsoToc4
	{mso-style-update:auto;
	mso-style-noshow:yes;
	mso-style-priority:39;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:33.1pt;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	font-variant:small-caps;
	color:black;}
p.MsoToc5, li.MsoToc5, div.MsoToc5
	{mso-style-update:auto;
	mso-style-noshow:yes;
	mso-style-priority:39;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:43.9pt;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	font-variant:small-caps;
	color:black;}
p.MsoToc6, li.MsoToc6, div.MsoToc6
	{mso-style-update:auto;
	mso-style-noshow:yes;
	mso-style-priority:39;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:54.7pt;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	font-variant:small-caps;
	color:black;}
p.MsoToc7, li.MsoToc7, div.MsoToc7
	{mso-style-update:auto;
	mso-style-noshow:yes;
	mso-style-priority:39;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:66.25pt;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	font-variant:small-caps;
	color:black;}
p.MsoToc8, li.MsoToc8, div.MsoToc8
	{mso-style-update:auto;
	mso-style-noshow:yes;
	mso-style-priority:39;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:77.0pt;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	font-variant:small-caps;
	color:black;}
p.MsoToc9, li.MsoToc9, div.MsoToc9
	{mso-style-update:auto;
	mso-style-noshow:yes;
	mso-style-priority:39;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:88.0pt;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	font-variant:small-caps;
	color:black;}
p.MsoHeader, li.MsoHeader, div.MsoHeader
	{mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-link:"Intestazione Carattere";
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:0cm;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:black;}
p.MsoFooter, li.MsoFooter, div.MsoFooter
	{mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-link:"Pi� di pagina Carattere";
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:0cm;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:black;}
p.MsoCaption, li.MsoCaption, div.MsoCaption
	{mso-style-priority:35;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	margin:0cm;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:9.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	font-variant:small-caps;
	color:#732117;
	letter-spacing:.5pt;}
p.MsoListBullet, li.MsoListBullet, div.MsoListBullet
	{mso-style-noshow:yes;
	mso-style-priority:99;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:18.0pt;
	margin-bottom:.0001pt;
	text-indent:-18.0pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:black;}
p.MsoListBullet2, li.MsoListBullet2, div.MsoListBullet2
	{mso-style-noshow:yes;
	mso-style-priority:99;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:36.0pt;
	margin-bottom:.0001pt;
	text-indent:-18.0pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:black;}
p.MsoListBullet3, li.MsoListBullet3, div.MsoListBullet3
	{mso-style-noshow:yes;
	mso-style-priority:99;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:54.0pt;
	margin-bottom:.0001pt;
	text-indent:-18.0pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:black;}
p.MsoListBullet4, li.MsoListBullet4, div.MsoListBullet4
	{mso-style-noshow:yes;
	mso-style-priority:99;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:72.0pt;
	margin-bottom:.0001pt;
	text-indent:-18.0pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:black;}
p.MsoListBullet5, li.MsoListBullet5, div.MsoListBullet5
	{mso-style-noshow:yes;
	mso-style-priority:99;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:90.0pt;
	margin-bottom:.0001pt;
	text-indent:-18.0pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:black;}
p.MsoTitle, li.MsoTitle, div.MsoTitle
	{mso-style-priority:10;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-link:"Titolo Carattere";
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:0cm;
	text-align:center;
	mso-pagination:widow-orphan;
	font-size:24.0pt;
	font-family:"Franklin Gothic Book","sans-serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	font-variant:small-caps;
	color:#D34817;
	font-weight:bold;}
p.MsoBodyText, li.MsoBodyText, div.MsoBodyText
	{mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-link:"Corpo del testo Carattere";
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:11.0pt;
	margin-left:0cm;
	text-align:justify;
	line-height:11.0pt;
	mso-pagination:widow-orphan;
	font-size:10.0pt;
	font-family:"Arial","sans-serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	letter-spacing:-.25pt;}
p.MsoSubtitle, li.MsoSubtitle, div.MsoSubtitle
	{mso-style-priority:11;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-link:"Sottotitolo Carattere";
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:24.0pt;
	margin-left:0cm;
	text-align:center;
	mso-pagination:widow-orphan;
	font-size:14.0pt;
	font-family:"Franklin Gothic Book","sans-serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";}
p.MsoBlockText, li.MsoBlockText, div.MsoBlockText
	{mso-style-name:"Testo del blocco\,Quote";
	mso-style-noshow:yes;
	mso-style-priority:99;
	margin-top:0cm;
	margin-right:72.0pt;
	margin-bottom:14.0pt;
	margin-left:72.0pt;
	text-align:justify;
	mso-pagination:widow-orphan;
	font-size:14.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:#7F7F7F;}
a:link, span.MsoHyperlink
	{mso-style-noshow:yes;
	mso-style-priority:99;
	color:#CC9900;
	text-decoration:underline;
	text-underline:single;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-noshow:yes;
	mso-style-priority:99;
	color:#96A9A9;
	text-decoration:underline;
	text-underline:single;}
strong
	{mso-style-priority:22;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	font-family:"Perpetua","serif";
	mso-ascii-font-family:Perpetua;
	mso-hansi-font-family:Perpetua;
	color:#9B2D1F;}
em
	{mso-style-priority:20;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	font-family:"Times New Roman","serif";
	mso-ascii-font-family:"Times New Roman";
	mso-hansi-font-family:"Times New Roman";
	mso-bidi-font-family:"Times New Roman";
	color:#404040;
	letter-spacing:.1pt;
	font-weight:bold;}
p.MsoAcetate, li.MsoAcetate, div.MsoAcetate
	{mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-link:"Testo fumetto Carattere";
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:0cm;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:8.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:black;}
span.MsoPlaceholderText
	{mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-unhide:no;
	color:gray;}
p.MsoNoSpacing, li.MsoNoSpacing, div.MsoNoSpacing
	{mso-style-priority:1;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	margin:0cm;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:black;}
p.MsoListParagraph, li.MsoListParagraph, div.MsoListParagraph
	{mso-style-priority:34;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:36.0pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:black;}
p.MsoQuote, li.MsoQuote, div.MsoQuote
	{mso-style-priority:29;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-link:"Citazione Carattere";
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:0cm;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:12.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:#7F7F7F;
	font-style:italic;}
p.MsoIntenseQuote, li.MsoIntenseQuote, div.MsoIntenseQuote
	{mso-style-priority:30;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-link:"Citazione intensa Carattere";
	margin-top:0cm;
	margin-right:72.0pt;
	margin-bottom:8.0pt;
	margin-left:72.0pt;
	text-align:center;
	line-height:115%;
	mso-pagination:widow-orphan;
	background:#D34817;
	font-size:16.0pt;
	font-family:"Franklin Gothic Book","sans-serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:white;
	font-style:italic;}
span.MsoSubtleEmphasis
	{mso-style-priority:19;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	font-family:"Perpetua","serif";
	mso-ascii-font-family:Perpetua;
	mso-hansi-font-family:Perpetua;
	color:#737373;
	letter-spacing:.1pt;
	font-style:italic;}
span.MsoIntenseEmphasis
	{mso-style-priority:21;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	font-family:"Perpetua","serif";
	mso-ascii-font-family:Perpetua;
	mso-hansi-font-family:Perpetua;
	font-variant:small-caps;
	color:#9B2D1F;
	letter-spacing:.1pt;
	font-weight:bold;
	font-style:italic;}
span.MsoSubtleReference
	{mso-style-priority:31;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	color:#737373;
	text-decoration:underline;
	text-underline:single;}
span.MsoIntenseReference
	{mso-style-priority:32;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	color:#D34817;
	font-weight:bold;
	text-decoration:underline;
	text-underline:single;}
span.MsoBookTitle
	{mso-style-priority:33;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	font-family:"Franklin Gothic Book","sans-serif";
	mso-ascii-font-family:"Franklin Gothic Book";
	mso-hansi-font-family:"Franklin Gothic Book";
	color:#855D5D;
	font-style:italic;}
p.MsoTocHeading, li.MsoTocHeading, div.MsoTocHeading
	{mso-style-priority:39;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	margin-top:24.0pt;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:0cm;
	margin-bottom:.0001pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	page-break-after:avoid;
	font-size:14.0pt;
	font-family:"Franklin Gothic Book","sans-serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:#9D3511;
	font-weight:bold;}
span.Titolo1Carattere
	{mso-style-name:"Titolo 1 Carattere";
	mso-style-priority:9;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Titolo 1";
	font-family:"Franklin Gothic Book","sans-serif";
	mso-ascii-font-family:"Franklin Gothic Book";
	mso-hansi-font-family:"Franklin Gothic Book";
	color:#9D3511;
	letter-spacing:1.0pt;
	font-weight:bold;}
span.Titolo2Carattere
	{mso-style-name:"Titolo 2 Carattere";
	mso-style-noshow:yes;
	mso-style-priority:9;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Titolo 2";
	font-family:"Franklin Gothic Book","sans-serif";
	mso-ascii-font-family:"Franklin Gothic Book";
	mso-hansi-font-family:"Franklin Gothic Book";
	color:#9D3511;
	letter-spacing:1.0pt;
	font-weight:bold;}
span.Titolo3Carattere
	{mso-style-name:"Titolo 3 Carattere";
	mso-style-noshow:yes;
	mso-style-priority:9;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Titolo 3";
	font-family:"Franklin Gothic Book","sans-serif";
	mso-ascii-font-family:"Franklin Gothic Book";
	mso-hansi-font-family:"Franklin Gothic Book";
	color:#D34817;
	letter-spacing:1.0pt;
	font-weight:bold;}
span.Titolo4Carattere
	{mso-style-name:"Titolo 4 Carattere";
	mso-style-noshow:yes;
	mso-style-priority:9;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Titolo 4";
	font-family:"Franklin Gothic Book","sans-serif";
	mso-ascii-font-family:"Franklin Gothic Book";
	mso-hansi-font-family:"Franklin Gothic Book";
	color:#7B6A4D;
	letter-spacing:1.0pt;
	font-weight:bold;}
span.Titolo5Carattere
	{mso-style-name:"Titolo 5 Carattere";
	mso-style-noshow:yes;
	mso-style-priority:9;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Titolo 5";
	font-family:"Franklin Gothic Book","sans-serif";
	mso-ascii-font-family:"Franklin Gothic Book";
	mso-hansi-font-family:"Franklin Gothic Book";
	color:#7B6A4D;
	letter-spacing:1.0pt;
	font-weight:bold;
	font-style:italic;}
span.Titolo6Carattere
	{mso-style-name:"Titolo 6 Carattere";
	mso-style-noshow:yes;
	mso-style-priority:9;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Titolo 6";
	font-family:"Franklin Gothic Book","sans-serif";
	mso-ascii-font-family:"Franklin Gothic Book";
	mso-hansi-font-family:"Franklin Gothic Book";
	color:#524633;
	letter-spacing:.5pt;}
span.Titolo7Carattere
	{mso-style-name:"Titolo 7 Carattere";
	mso-style-noshow:yes;
	mso-style-priority:9;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Titolo 7";
	font-family:"Franklin Gothic Book","sans-serif";
	mso-ascii-font-family:"Franklin Gothic Book";
	mso-hansi-font-family:"Franklin Gothic Book";
	color:#524633;
	letter-spacing:.5pt;
	font-style:italic;}
span.Titolo8Carattere
	{mso-style-name:"Titolo 8 Carattere";
	mso-style-noshow:yes;
	mso-style-priority:9;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Titolo 8";
	font-family:"Franklin Gothic Book","sans-serif";
	mso-ascii-font-family:"Franklin Gothic Book";
	mso-hansi-font-family:"Franklin Gothic Book";
	color:#D34817;
	letter-spacing:.5pt;}
span.Titolo9Carattere
	{mso-style-name:"Titolo 9 Carattere";
	mso-style-noshow:yes;
	mso-style-priority:9;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Titolo 9";
	font-family:"Franklin Gothic Book","sans-serif";
	mso-ascii-font-family:"Franklin Gothic Book";
	mso-hansi-font-family:"Franklin Gothic Book";
	color:#D34817;
	letter-spacing:.5pt;
	font-style:italic;}
span.IntestazioneCarattere
	{mso-style-name:"Intestazione Carattere";
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:Intestazione;
	color:black;}
span.PidipaginaCarattere
	{mso-style-name:"Pi� di pagina Carattere";
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Pi� di pagina";
	color:black;}
span.TitoloCarattere
	{mso-style-name:"Titolo Carattere";
	mso-style-priority:10;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:Titolo;
	font-family:"Franklin Gothic Book","sans-serif";
	mso-ascii-font-family:"Franklin Gothic Book";
	mso-hansi-font-family:"Franklin Gothic Book";
	font-variant:small-caps;
	color:#D34817;
	font-weight:bold;}
span.CorpodeltestoCarattere
	{mso-style-name:"Corpo del testo Carattere";
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Corpo del testo";
	font-family:"Arial","sans-serif";
	mso-ascii-font-family:Arial;
	mso-hansi-font-family:Arial;
	mso-bidi-font-family:Arial;
	letter-spacing:-.25pt;}
span.SottotitoloCarattere
	{mso-style-name:"Sottotitolo Carattere";
	mso-style-priority:11;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:Sottotitolo;
	font-family:"Franklin Gothic Book","sans-serif";
	mso-ascii-font-family:"Franklin Gothic Book";
	mso-hansi-font-family:"Franklin Gothic Book";}
span.TestofumettoCarattere
	{mso-style-name:"Testo fumetto Carattere";
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Testo fumetto";
	font-family:"Tahoma","sans-serif";
	mso-ascii-font-family:Tahoma;
	mso-hansi-font-family:Tahoma;
	mso-bidi-font-family:Tahoma;
	color:black;}
span.CitazioneCarattere
	{mso-style-name:"Citazione Carattere";
	mso-style-priority:29;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:Citazione;
	color:#7F7F7F;
	font-style:italic;}
span.CitazioneintensaCarattere
	{mso-style-name:"Citazione intensa Carattere";
	mso-style-priority:30;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Citazione intensa";
	font-family:"Franklin Gothic Book","sans-serif";
	mso-ascii-font-family:"Franklin Gothic Book";
	mso-hansi-font-family:"Franklin Gothic Book";
	color:white;
	background:#D34817;
	font-style:italic;}
p.msolistbulletcxspfirst, li.msolistbulletcxspfirst, div.msolistbulletcxspfirst
	{mso-style-name:msolistbulletcxspfirst;
	mso-style-unhide:no;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:18.0pt;
	margin-bottom:.0001pt;
	text-indent:-18.0pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:black;}
p.msolistbulletcxspmiddle, li.msolistbulletcxspmiddle, div.msolistbulletcxspmiddle
	{mso-style-name:msolistbulletcxspmiddle;
	mso-style-unhide:no;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:18.0pt;
	margin-bottom:.0001pt;
	text-indent:-18.0pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:black;}
p.msolistbulletcxsplast, li.msolistbulletcxsplast, div.msolistbulletcxsplast
	{mso-style-name:msolistbulletcxsplast;
	mso-style-unhide:no;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:18.0pt;
	margin-bottom:.0001pt;
	text-indent:-18.0pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:black;}
p.msotitlecxspfirst, li.msotitlecxspfirst, div.msotitlecxspfirst
	{mso-style-name:msotitlecxspfirst;
	mso-style-unhide:no;
	mso-style-link:"Titolo Carattere";
	margin:0cm;
	margin-bottom:.0001pt;
	text-align:center;
	mso-pagination:widow-orphan;
	font-size:24.0pt;
	font-family:"Franklin Gothic Book","sans-serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	font-variant:small-caps;
	color:#D34817;
	font-weight:bold;}
p.msotitlecxspmiddle, li.msotitlecxspmiddle, div.msotitlecxspmiddle
	{mso-style-name:msotitlecxspmiddle;
	mso-style-unhide:no;
	mso-style-link:"Titolo Carattere";
	margin:0cm;
	margin-bottom:.0001pt;
	text-align:center;
	mso-pagination:widow-orphan;
	font-size:24.0pt;
	font-family:"Franklin Gothic Book","sans-serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	font-variant:small-caps;
	color:#D34817;
	font-weight:bold;}
p.msotitlecxsplast, li.msotitlecxsplast, div.msotitlecxsplast
	{mso-style-name:msotitlecxsplast;
	mso-style-unhide:no;
	mso-style-link:"Titolo Carattere";
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:0cm;
	text-align:center;
	mso-pagination:widow-orphan;
	font-size:24.0pt;
	font-family:"Franklin Gothic Book","sans-serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	font-variant:small-caps;
	color:#D34817;
	font-weight:bold;}
p.msolistparagraphcxspfirst, li.msolistparagraphcxspfirst, div.msolistparagraphcxspfirst
	{mso-style-name:msolistparagraphcxspfirst;
	mso-style-unhide:no;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:36.0pt;
	margin-bottom:.0001pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:black;}
p.msolistparagraphcxspmiddle, li.msolistparagraphcxspmiddle, div.msolistparagraphcxspmiddle
	{mso-style-name:msolistparagraphcxspmiddle;
	mso-style-unhide:no;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:36.0pt;
	margin-bottom:.0001pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:black;}
p.msolistparagraphcxsplast, li.msolistparagraphcxsplast, div.msolistparagraphcxsplast
	{mso-style-name:msolistparagraphcxsplast;
	mso-style-unhide:no;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:36.0pt;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Perpetua","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";
	color:black;}
p.Istituzione, li.Istituzione, div.Istituzione
	{mso-style-name:Istituzione;
	mso-style-unhide:no;
	margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:3.0pt;
	margin-left:0cm;
	line-height:11.0pt;
	mso-pagination:widow-orphan;
	font-size:10.0pt;
	font-family:"Arial","sans-serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;}
p.msopapdefault, li.msopapdefault, div.msopapdefault
	{mso-style-name:msopapdefault;
	mso-style-unhide:no;
	mso-margin-top-alt:auto;
	margin-right:0cm;
	margin-bottom:10.0pt;
	margin-left:0cm;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;}
.MsoChpDefault
	{mso-style-type:export-only;
	mso-default-props:yes;
	font-size:10.0pt;
	mso-ansi-font-size:10.0pt;
	mso-bidi-font-size:10.0pt;}
@page Section1
	{size:21.0cm 841.95pt;
	margin:70.9pt 70.9pt 70.9pt 70.9pt;
	mso-header-margin:35.4pt;
	mso-footer-margin:35.4pt;
	mso-paper-source:0;}
div.Section1
	{page:Section1;}
 /* List Definitions */
 @list l0
	{mso-list-id:-128;
	mso-list-type:simple;
	mso-list-template-ids:-744180608;}
@list l0:level1
	{mso-level-number-format:bullet;
	mso-level-style-link:"Punto elenco 5";
	mso-level-text:\F0B7;
	mso-level-tab-stop:74.6pt;
	mso-level-number-position:left;
	margin-left:74.6pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l1
	{mso-list-id:-127;
	mso-list-type:simple;
	mso-list-template-ids:-1537807362;}
@list l1:level1
	{mso-level-number-format:bullet;
	mso-level-style-link:"Punto elenco 4";
	mso-level-text:\F0B7;
	mso-level-tab-stop:60.45pt;
	mso-level-number-position:left;
	margin-left:60.45pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l2
	{mso-list-id:-126;
	mso-list-type:simple;
	mso-list-template-ids:-1142797826;}
@list l2:level1
	{mso-level-number-format:bullet;
	mso-level-style-link:"Punto elenco 3";
	mso-level-text:\F0B7;
	mso-level-tab-stop:46.3pt;
	mso-level-number-position:left;
	margin-left:46.3pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l3
	{mso-list-id:-125;
	mso-list-type:simple;
	mso-list-template-ids:-1278169612;}
@list l3:level1
	{mso-level-number-format:bullet;
	mso-level-style-link:"Punto elenco 2";
	mso-level-text:\F0B7;
	mso-level-tab-stop:32.15pt;
	mso-level-number-position:left;
	margin-left:32.15pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l4
	{mso-list-id:-119;
	mso-list-type:simple;
	mso-list-template-ids:-1184579282;}
@list l4:level1
	{mso-level-number-format:bullet;
	mso-level-style-link:"Punto elenco";
	mso-level-text:\F0B7;
	mso-level-tab-stop:18.0pt;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l5
	{mso-list-id:319701838;
	mso-list-type:hybrid;
	mso-list-template-ids:1953430750 68157441 68157443 68157445 68157441 68157443 68157445 68157441 68157443 68157445;}
@list l5:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:57.3pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l6
	{mso-list-id:576591526;
	mso-list-type:hybrid;
	mso-list-template-ids:57688928 -772770394 68157443 68157445 68157441 68157443 68157445 68157441 68157443 68157445;}
@list l6:level1
	{mso-level-start-at:0;
	mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:42.6pt;
	text-indent:-18.0pt;
	mso-ansi-font-size:12.0pt;
	font-family:Symbol;
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";}
@list l7
	{mso-list-id:577592992;
	mso-list-type:hybrid;
	mso-list-template-ids:-758880422 1485985040 68157443 68157445 68157441 68157443 68157445 68157441 68157443 68157445;}
@list l7:level1
	{mso-level-start-at:0;
	mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:21.3pt;
	text-indent:-18.0pt;
	mso-ansi-font-size:12.0pt;
	font-family:Symbol;
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";}
@list l8
	{mso-list-id:1130319558;
	mso-list-type:hybrid;
	mso-list-template-ids:-725581370 -772770394 68157443 68157445 68157441 68157443 68157445 68157441 68157443 68157445;}
@list l8:level1
	{mso-level-start-at:0;
	mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	margin-left:39.3pt;
	text-indent:-18.0pt;
	mso-ansi-font-size:12.0pt;
	font-family:Symbol;
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-bidi-font-family:"Times New Roman";}
ol
	{margin-bottom:0cm;}
ul
	{margin-bottom:0cm;}
-->
</style>
<!--[if gte mso 10]>
<style>
 /* Style Definitions */
 table.MsoNormalTable
	{mso-style-name:"Tabella normale";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-qformat:yes;
	mso-style-parent:"";
	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
	mso-para-margin:0cm;
	mso-para-margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:10.0pt;
	font-family:"Times New Roman","serif";}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="5122"/>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1"/>
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=IT link="#CC9900" vlink="#96A9A9" style='tab-interval:35.4pt'>

<div class=Section1>

<p class=MsoNormal style='margin-top:5.0pt;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><b style='mso-bidi-font-weight:normal'><span
style='font-size:24.0pt;line-height:115%;font-family:"Franklin Gothic Book","sans-serif";
color:#D34817;mso-no-proof:yes'><img width=187 height=187 id="_x0000_i1065"
src="effedoc_file/image001.png"></span></b></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt'><span lang=EN-US style='display:none;
mso-hide:all;mso-ansi-language:EN-US'><o:p>&nbsp;</o:p></span></p>

<span style='left:0pt;position:absolute;z-index:2'><span style='font-size:12.0pt;
font-family:"Times New Roman","serif";mso-fareast-font-family:"Times New Roman";
mso-ansi-language:IT;mso-fareast-language:IT;mso-bidi-language:AR-SA'><br
clear=all style='page-break-before:always'>
</span>

<p class=MsoTitle align=left style='margin-left:21.3pt;text-align:left'><span
style='text-transform:uppercase'>eFFe Document<o:p></o:p></span></p>

<p class=MsoSubtitle align=left style='margin-left:21.3pt;text-align:left'><span
style='font-variant:small-caps;color:#D34817;text-transform:uppercase'>Versione
1.0.0 build 100<o:p></o:p></span></p>

<p class=MsoTocHeading style='margin-left:21.3pt'><span style='font-variant:
small-caps;text-transform:uppercase'>Sommario<o:p></o:p></span></p>

<p class=MsoToc1 style='margin-left:21.3pt'><span style='text-transform:uppercase'><a
href="#_Toc248407493">Introduzione<span style='color:#9B2D1F;display:none;
mso-hide:all;text-decoration:none;text-underline:none'>. 2</span></a><o:p></o:p></span></p>

<p class=MsoToc1 style='margin-left:21.3pt'><span style='text-transform:uppercase'><a
href="#_Toc248407494">Preparazione del Server per l�installazione<span
style='color:#9B2D1F;display:none;mso-hide:all;text-decoration:none;text-underline:
none'>. 3</span></a><o:p></o:p></span></p>

<p class=MsoToc2 style='margin-left:21.3pt'><span style='text-transform:uppercase'><a
href="#_Toc248407495">Tecnologie utilizzate<span style='color:black;display:
none;mso-hide:all;text-decoration:none;text-underline:none'>. 3</span></a><o:p></o:p></span></p>

<p class=MsoToc2 style='margin-left:21.3pt'><span style='text-transform:uppercase'><a
href="#_Toc248407496">Preparazione del Server<span style='color:black;
display:none;mso-hide:all;text-decoration:none;text-underline:none'>.. 3</span></a><o:p></o:p></span></p>

<p class=MsoToc2 style='margin-left:21.3pt'><span style='text-transform:uppercase'><a
href="#_Toc248407497">Pre-Configurazione dell�ambiente server<span
style='color:black;display:none;mso-hide:all;text-decoration:none;text-underline:
none'>.. 3</span></a><o:p></o:p></span></p>

<p class=MsoToc2 style='margin-left:21.3pt'><span style='text-transform:uppercase'><a
href="#_Toc248407498">Installazione<span style='color:black;display:none;
mso-hide:all;text-decoration:none;text-underline:none'>. 3</span></a><o:p></o:p></span></p>

<p class=MsoToc2 style='margin-left:21.3pt'><span style='text-transform:uppercase'><a
href="#_Toc248407499">Configurazione accesso al DB e al Servizio LDAP<span
style='color:black;display:none;mso-hide:all;text-decoration:none;text-underline:
none'>. 3</span></a><o:p></o:p></span></p>

<p class=MsoToc1 style='margin-left:21.3pt'><span style='text-transform:uppercase'><a
href="#_Toc248407500">Work Flow gestiti da EffE Document<span style='color:
#9B2D1F;display:none;mso-hide:all;text-decoration:none;text-underline:none'>. 5</span></a><o:p></o:p></span></p>

<p class=MsoToc2 style='margin-left:21.3pt'><span style='text-transform:uppercase'><a
href="#_Toc248407501">Workflow Semplice<span style='color:black;display:none;
mso-hide:all;text-decoration:none;text-underline:none'>. 5</span></a><o:p></o:p></span></p>

<p class=MsoToc2 style='margin-left:21.3pt'><span style='text-transform:uppercase'><a
href="#_Toc248407502">Workflow Avanzato<span style='color:black;display:none;
mso-hide:all;text-decoration:none;text-underline:none'>.. 6</span></a><o:p></o:p></span></p>

<p class=MsoToc1 style='margin-left:21.3pt'><span style='text-transform:uppercase'><a
href="#_Toc248407503">Generazione Numero di Protocollo<span style='color:#9B2D1F;
display:none;mso-hide:all;text-decoration:none;text-underline:none'>.. 7</span></a><o:p></o:p></span></p>

<p class=MsoToc1 style='margin-left:21.3pt'><span style='text-transform:uppercase'><a
href="#_Toc248407504">Sistema di Back End<span style='color:#9B2D1F;display:
none;mso-hide:all;text-decoration:none;text-underline:none'>.. 8</span></a><o:p></o:p></span></p>

<p class=MsoToc2 style='margin-left:21.3pt'><span style='text-transform:uppercase'><a
href="#_Toc248407505">Amministratore<span style='color:black;display:none;
mso-hide:all;text-decoration:none;text-underline:none'>. 9</span></a><o:p></o:p></span></p>

<p class=MsoToc2 style='margin-left:21.3pt'><span style='text-transform:uppercase'><a
href="#_Toc248407506">Responsabile Area Tematica<span style='color:black;
display:none;mso-hide:all;text-decoration:none;text-underline:none'>.. 10</span></a><o:p></o:p></span></p>

<p class=MsoToc2 style='margin-left:21.3pt'><span style='text-transform:uppercase'><a
href="#_Toc248407507">Protocollatore<span style='color:black;display:none;
mso-hide:all;text-decoration:none;text-underline:none'>. 10</span></a><o:p></o:p></span></p>

<p class=MsoToc2 style='margin-left:21.3pt'><span style='text-transform:uppercase'><a
href="#_Toc248407508">Collaboratore<span style='color:black;display:none;
mso-hide:all;text-decoration:none;text-underline:none'>. 11</span></a><o:p></o:p></span></p>

<p class=MsoToc2 style='margin-left:21.3pt'><span style='text-transform:uppercase'><a
href="#_Toc248407509">Responsabile di Servizio<span style='color:black;
display:none;mso-hide:all;text-decoration:none;text-underline:none'>.. 12</span></a><o:p></o:p></span></p>

<p class=MsoToc2 style='margin-left:21.3pt'><span style='text-transform:uppercase'><a
href="#_Toc248407510">Visualizzatore Report<span style='color:black;display:
none;mso-hide:all;text-decoration:none;text-underline:none'>. 12</span></a><o:p></o:p></span></p>

<p class=MsoToc1 style='margin-left:21.3pt'><span style='text-transform:uppercase'><a
href="#_Toc248407511">Sistema di Front � End<span style='color:#9B2D1F;
display:none;mso-hide:all;text-decoration:none;text-underline:none'>.. 13</span></a><o:p></o:p></span></p>

<p class=MsoToc2 style='margin-left:21.3pt'><span style='text-transform:uppercase'><a
href="#_Toc248407512">Apertura di un nuovo documento<span style='color:black;
display:none;mso-hide:all;text-decoration:none;text-underline:none'>.. 14</span></a><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-variant:small-caps;
text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<span style='font-size:11.0pt;line-height:115%;font-family:"Perpetua","serif";
mso-fareast-font-family:"Times New Roman";mso-bidi-font-family:"Times New Roman";
font-variant:small-caps;color:black;text-transform:uppercase;mso-ansi-language:
IT;mso-fareast-language:IT;mso-bidi-language:AR-SA'><br clear=all
style='page-break-before:always'>
</span>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><span style='font-variant:small-caps;text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<h1 style='margin-left:21.3pt'><a name="_Toc248407493"><span style='mso-fareast-font-family:
"Times New Roman";font-variant:small-caps;text-transform:uppercase'>Introduzione</span></a><span
style='mso-fareast-font-family:"Times New Roman";font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></h1>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-variant:small-caps;
text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>EffE
Document � una Web Application OpenSource per la gestione documentale.</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt;page-break-after:avoid'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase;mso-no-proof:yes'><img border=0 width=605 height=342 id="_x0000_i1064"
src="effedoc_file/image004.png" alt=launch.png></span><span style='font-variant:
small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoCaption align=center style='margin-left:21.3pt;text-align:center'><span
style='font-size:10.0pt;text-transform:uppercase'>Figura 1 - Launch Panel</span><span
style='text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>&nbsp;</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>Realizzato
completamente con tecnologie Open Source (php 5, mysql 5, apache 2) � composto
da due elementi chiave:</span><span style='font-variant:small-caps;text-transform:
uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><b><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>1.</span></b><b><span style='font-size:7.0pt;line-height:115%;
font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></b><b><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Il sistema di front-end</span></b><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><b><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>2.</span></b><b><span style='font-size:7.0pt;line-height:115%;
font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></b><b><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Il sistema di back-end</span></b><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt;text-align:justify'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Il sistema di <i>Front-End</i> � accessibile all�utente esterno
all�organizzazione che vuole inoltrare un documento ed ottenere un numero di
protocollo relativo.</span><span style='font-variant:small-caps;text-transform:
uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt;text-align:justify'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Accessibile attraverso un url tipo: </span><span style='font-variant:
small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;text-indent:35.45pt'><b><span
lang=EN-US style='font-size:12.0pt;line-height:115%;font-variant:small-caps;
text-transform:uppercase;mso-ansi-language:EN-US'>http://www.mywebsite:8080/effedocument/</span></b><span
lang=EN-US style='font-variant:small-caps;text-transform:uppercase;mso-ansi-language:
EN-US'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;text-indent:35.45pt'><span
lang=EN-US style='font-size:12.0pt;line-height:115%;font-variant:small-caps;
text-transform:uppercase;mso-ansi-language:EN-US'>oppure <b>http://www.mywebsite:8080/effedocument/index.php</b></span><span
lang=EN-US style='font-variant:small-caps;text-transform:uppercase;mso-ansi-language:
EN-US'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt;text-align:justify;text-indent:
35.45pt'><span lang=EN-US style='font-size:12.0pt;line-height:115%;font-variant:
small-caps;text-transform:uppercase;mso-ansi-language:EN-US'>&nbsp;</span><span
lang=EN-US style='font-variant:small-caps;text-transform:uppercase;mso-ansi-language:
EN-US'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt;text-align:justify'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Una volta caricata la web application l�utente potr� procedere nell�inoltro
del proprio documento. Tale procedura verr� a dettagliata nel seguito.</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt;text-align:justify'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Il sistema di <i>Back-End</i> � la parte di applicazione riservata
agli utenti interni dell�azienda ed offre tutti gli strumenti necessari per la gestione
dei documenti e per l�amministrazione della web application stessa attraverso
l�account di amministratore.</span><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>&nbsp;</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<h1 style='margin-left:21.3pt'><a name="_Toc248407494"><span style='mso-fareast-font-family:
"Times New Roman";font-variant:small-caps;text-transform:uppercase'>Preparazione
del Server per l�installazione</span></a><span style='mso-fareast-font-family:
"Times New Roman";font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></h1>

<h2 style='margin-left:21.3pt'><a name="_Toc248407495"><span style='mso-fareast-font-family:
"Times New Roman";font-variant:small-caps;text-transform:uppercase'>Tecnologie
utilizzate</span></a><span style='mso-fareast-font-family:"Times New Roman";
font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></h2>

<p class=MsoListParagraph style='margin-top:0cm;margin-right:0cm;margin-bottom:
0cm;margin-left:53.4pt;margin-bottom:.0001pt;text-indent:-18.0pt'><span
style='font-size:13.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span
style='font-size:13.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Linguaggio lato server: <b>PHP 5.3.0</b></span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-top:0cm;margin-right:0cm;margin-bottom:
0cm;margin-left:53.4pt;margin-bottom:.0001pt;text-indent:-18.0pt'><span
style='font-size:13.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span
style='font-size:13.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Linguaggio lato client:<b> HTML, JAVA SCRIPT</b></span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:13.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span lang=EN-US style='font-size:7.0pt;
line-height:115%;font-family:"Times New Roman","serif";font-variant:small-caps;
text-transform:uppercase;mso-ansi-language:EN-US'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span><span lang=EN-US style='font-size:13.0pt;line-height:115%;font-variant:
small-caps;text-transform:uppercase;mso-ansi-language:EN-US'>Database: <b>MySQL
5.1.36</b></span><span lang=EN-US style='font-variant:small-caps;text-transform:
uppercase;mso-ansi-language:EN-US'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:13.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span lang=EN-US style='font-size:7.0pt;
line-height:115%;font-family:"Times New Roman","serif";font-variant:small-caps;
text-transform:uppercase;mso-ansi-language:EN-US'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span><span lang=EN-US style='font-size:13.0pt;line-height:115%;font-variant:
small-caps;text-transform:uppercase;mso-ansi-language:EN-US'>Web Server: <b>Apache
2.2.11</b></span><span lang=EN-US style='font-variant:small-caps;text-transform:
uppercase;mso-ansi-language:EN-US'><o:p></o:p></span></p>

<h2 style='margin-left:21.3pt'><a name="_Toc248407496"><span style='mso-fareast-font-family:
"Times New Roman";font-variant:small-caps;text-transform:uppercase'>Preparazione
del Server</span></a><span style='mso-fareast-font-family:"Times New Roman";
font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></h2>

<p class=MsoNormal style='margin-left:21.3pt;text-align:justify'><span
style='font-size:13.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Per l�utilizzo di EffE Document si consiglia l�installazione del
pacchetto open source WAMP, scaricabile da sito web: <b>http://www.wampserver.com/</b>
che comprende tutti i tool citati sopra e ne permette una rapida e semplice
configurazione.</span><span style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt;text-align:justify'><span
style='font-size:13.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>In alternativa, se tali software sono gi� presenti sul sistema e la
loro versione � uguale o equivalente, � possibile installare direttamente EffE
Document.</span><span style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<h2 style='margin-left:21.3pt'><a name="_Toc248407497"><span style='mso-fareast-font-family:
"Times New Roman";font-variant:small-caps;text-transform:uppercase'>Pre-Configurazione
dell�ambiente server</span></a><span style='mso-fareast-font-family:"Times New Roman";
font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></h2>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:6.0pt;
margin-left:21.3pt;text-align:justify'><span style='font-size:13.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>Abilitare i
moduli <b>Mime Magic, LDAP</b> e <b>SEND MAIL FROM</b> di PHP nel file PHP.INI</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-align:justify;
text-indent:-18.0pt'><span lang=EN-US style='font-size:13.0pt;line-height:115%;
font-family:Symbol;font-variant:small-caps;text-transform:uppercase;mso-ansi-language:
EN-US'>�</span><span lang=EN-US style='font-size:7.0pt;line-height:115%;
font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase;mso-ansi-language:EN-US'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><b><span
lang=EN-US style='font-size:13.0pt;line-height:115%;font-variant:small-caps;
text-transform:uppercase;mso-ansi-language:EN-US'>extension=php_mime_magic.dll</span></b><span
lang=EN-US style='font-variant:small-caps;text-transform:uppercase;mso-ansi-language:
EN-US'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-align:justify;
text-indent:-18.0pt'><span lang=EN-US style='font-size:13.0pt;line-height:115%;
font-family:Symbol;font-variant:small-caps;text-transform:uppercase;mso-ansi-language:
EN-US'>�</span><span lang=EN-US style='font-size:7.0pt;line-height:115%;
font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase;mso-ansi-language:EN-US'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><b><span
lang=EN-US style='font-size:13.0pt;line-height:115%;font-variant:small-caps;
text-transform:uppercase;mso-ansi-language:EN-US'>extension=php_ldap.dll</span></b><span
lang=EN-US style='font-variant:small-caps;text-transform:uppercase;mso-ansi-language:
EN-US'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-align:justify;
text-indent:-18.0pt'><span style='font-size:13.0pt;line-height:115%;font-family:
Symbol;font-variant:small-caps;text-transform:uppercase'>�</span><span
style='font-size:7.0pt;line-height:115%;font-family:"Times New Roman","serif";
font-variant:small-caps;text-transform:uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span><span style='font-size:13.0pt;line-height:115%;font-variant:small-caps;
text-transform:uppercase'>sezione <b>[mail function] </b>nel<b> </b>file<b>
php.ini</b></span><span style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<h2 style='margin-left:21.3pt'><a name="_Toc248407498"><span style='mso-fareast-font-family:
"Times New Roman";font-variant:small-caps;text-transform:uppercase'>Installazione</span></a><span
style='mso-fareast-font-family:"Times New Roman";font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></h2>

<p class=MsoListParagraph style='margin-left:53.4pt;text-align:justify;
text-indent:-18.0pt'><span style='font-size:13.0pt;line-height:115%;font-variant:
small-caps;text-transform:uppercase'>1.</span><span style='font-size:7.0pt;
line-height:115%;font-family:"Times New Roman","serif";font-variant:small-caps;
text-transform:uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span
style='font-size:13.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Scompattare il pacchetto <b>effedocument_blank_schema.zip</b> nella
directory WWW di APACHE .</span><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-align:justify;
text-indent:-18.0pt'><span style='font-size:13.0pt;line-height:115%;font-variant:
small-caps;text-transform:uppercase'>2.</span><span style='font-size:7.0pt;
line-height:115%;font-family:"Times New Roman","serif";font-variant:small-caps;
text-transform:uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span
style='font-size:13.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Caricare lo Schema del DB <b>effedocument_blank_schema.sql</b> in
mysql.</span><span style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt;text-align:justify'><span
style='font-size:13.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>&nbsp;</span><span style='font-variant:small-caps;text-transform:
uppercase'><o:p></o:p></span></p>

<h2 style='margin-left:21.3pt'><a name="_Toc248407499"><span style='mso-fareast-font-family:
"Times New Roman";font-variant:small-caps;text-transform:uppercase'>Configurazione
accesso al DB e al Servizio LDAP</span></a><span style='mso-fareast-font-family:
"Times New Roman";font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></h2>

<p class=MsoNormal style='margin-left:21.3pt;text-align:justify'><span
style='font-size:13.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Le impostazioni di accesso al DB e al servizio LDAP sono settate
attraverso il file <b><i>EFFECONFIG.XML</i></b> presente nella directory <b>COMMON/<i>CORE/</i></b>:</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
lang=EN-US style='font-variant:small-caps;color:#0070C0;text-transform:uppercase;
mso-ansi-language:EN-US'>&lt;?xml version=&quot;1.0&quot;
encoding=&quot;utf-8&quot;?&gt;</span></b><span lang=EN-US style='font-variant:
small-caps;text-transform:uppercase;mso-ansi-language:EN-US'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
lang=EN-US style='font-variant:small-caps;color:#0070C0;text-transform:uppercase;
mso-ansi-language:EN-US'>&lt;effeconfig&gt;</span></b><span lang=EN-US
style='font-variant:small-caps;text-transform:uppercase;mso-ansi-language:EN-US'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
lang=EN-US style='font-variant:small-caps;color:#0070C0;text-transform:uppercase;
mso-ansi-language:EN-US'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&lt;database&gt;</span></b><span lang=EN-US style='font-variant:small-caps;
text-transform:uppercase;mso-ansi-language:EN-US'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
lang=EN-US style='font-variant:small-caps;color:#0070C0;text-transform:uppercase;
mso-ansi-language:EN-US'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&lt;user&gt;root&lt;/user&gt;</span></b><span lang=EN-US style='font-variant:
small-caps;text-transform:uppercase;mso-ansi-language:EN-US'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
lang=EN-US style='font-variant:small-caps;color:#0070C0;text-transform:uppercase;
mso-ansi-language:EN-US'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&lt;password&gt;&lt;/password&gt;</span></b><span lang=EN-US style='font-variant:
small-caps;text-transform:uppercase;mso-ansi-language:EN-US'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
lang=EN-US style='font-variant:small-caps;color:#0070C0;text-transform:uppercase;
mso-ansi-language:EN-US'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&lt;host&gt;localhost&lt;/host&gt;</span></b><span lang=EN-US style='font-variant:
small-caps;text-transform:uppercase;mso-ansi-language:EN-US'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
lang=EN-US style='font-variant:small-caps;color:#0070C0;text-transform:uppercase;
mso-ansi-language:EN-US'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&lt;dbname&gt;effedocument&lt;/dbname&gt;</span></b><span lang=EN-US
style='font-variant:small-caps;text-transform:uppercase;mso-ansi-language:EN-US'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
lang=EN-US style='font-variant:small-caps;color:#0070C0;text-transform:uppercase;
mso-ansi-language:EN-US'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&lt;/database&gt;</span></b><span lang=EN-US style='font-variant:small-caps;
text-transform:uppercase;mso-ansi-language:EN-US'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
lang=EN-US style='font-variant:small-caps;color:#0070C0;text-transform:uppercase;
mso-ansi-language:EN-US'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&lt;ldap&gt;</span></b><span lang=EN-US style='font-variant:small-caps;
text-transform:uppercase;mso-ansi-language:EN-US'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
lang=EN-US style='font-variant:small-caps;color:#0070C0;text-transform:uppercase;
mso-ansi-language:EN-US'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&lt;server&gt;ldap://127.0.0.1&lt;/server&gt;</span></b><span lang=EN-US
style='font-variant:small-caps;text-transform:uppercase;mso-ansi-language:EN-US'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
lang=EN-US style='font-variant:small-caps;color:#0070C0;text-transform:uppercase;
mso-ansi-language:EN-US'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&lt;partialdn&gt;ou=myou,o=myo,dc=mydc,dc=it&lt;/partialdn&gt;</span></b><span
lang=EN-US style='font-variant:small-caps;text-transform:uppercase;mso-ansi-language:
EN-US'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
lang=EN-US style='font-variant:small-caps;color:#0070C0;text-transform:uppercase;
mso-ansi-language:EN-US'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></b><b><span
style='font-variant:small-caps;color:#0070C0;text-transform:uppercase'>&lt;/ldap&gt;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
style='font-variant:small-caps;color:#0070C0;text-transform:uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&lt;other&gt;</span></b><span style='font-variant:small-caps;text-transform:
uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
style='font-variant:small-caps;color:#0070C0;text-transform:uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&lt;dirallegati&gt;../documenti_allegati/&lt;/dirallegati&gt;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
style='font-variant:small-caps;color:#0070C0;text-transform:uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></b><b><span lang=EN-US style='font-variant:small-caps;color:#0070C0;
text-transform:uppercase;mso-ansi-language:EN-US'>&lt;effelog
active='true'&gt;effedoclog.txt&lt;/effelog&gt;</span></b><span lang=EN-US
style='font-variant:small-caps;text-transform:uppercase;mso-ansi-language:EN-US'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
lang=EN-US style='font-variant:small-caps;color:#0070C0;text-transform:uppercase;
mso-ansi-language:EN-US'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></b><b><span
style='font-variant:small-caps;color:#0070C0;text-transform:uppercase'>&lt;/other&gt;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
style='font-variant:small-caps;color:#0070C0;text-transform:uppercase'>&lt;/effeconfig&gt;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
style='font-variant:small-caps;color:#0070C0;text-transform:uppercase'>&nbsp;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
style='font-variant:small-caps;color:windowtext;text-transform:uppercase'>&lt;Database&gt;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-top:0cm;margin-right:0cm;margin-bottom:
0cm;margin-left:53.4pt;margin-bottom:.0001pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><b><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>user</span></b><span style='font-size:12.0pt;line-height:115%;
font-variant:small-caps;text-transform:uppercase'>: utente del db</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-top:0cm;margin-right:0cm;margin-bottom:
0cm;margin-left:53.4pt;margin-bottom:.0001pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><b><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>password</span></b><span style='font-size:12.0pt;line-height:115%;
font-variant:small-caps;text-transform:uppercase'>: password di accesso al db</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-top:0cm;margin-right:0cm;margin-bottom:
0cm;margin-left:53.4pt;margin-bottom:.0001pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><b><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>host</span></b><span style='font-size:12.0pt;line-height:115%;
font-variant:small-caps;text-transform:uppercase'>: host del db</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-top:0cm;margin-right:0cm;margin-bottom:
0cm;margin-left:53.4pt;margin-bottom:.0001pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><b><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>dbname</span></b><span style='font-size:12.0pt;line-height:115%;
font-variant:small-caps;text-transform:uppercase'>: nome del db</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-top:0cm;margin-right:0cm;margin-bottom:
0cm;margin-left:53.4pt;margin-bottom:.0001pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>&nbsp;</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:53.4pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
style='font-variant:small-caps;color:windowtext;text-transform:uppercase'>&lt;LDAP&gt;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-top:0cm;margin-right:0cm;margin-bottom:
0cm;margin-left:53.4pt;margin-bottom:.0001pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><b><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>server</span></b><span style='font-size:12.0pt;line-height:115%;
font-variant:small-caps;text-transform:uppercase'>: server del servizio ldap</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-top:0cm;margin-right:0cm;margin-bottom:
0cm;margin-left:53.4pt;margin-bottom:.0001pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><b><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>partialdn</span></b><span style='font-size:12.0pt;line-height:115%;
font-variant:small-caps;text-transform:uppercase'>: dn finale di autenticazione,
escluso il <b>cn</b> dell�utente</span><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:53.4pt;margin-bottom:.0001pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>&nbsp;</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:53.4pt;margin-bottom:.0001pt;text-align:justify;line-height:normal'><b><span
style='font-variant:small-caps;color:windowtext;text-transform:uppercase'>&lt;OTHER&gt;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-top:0cm;margin-right:0cm;margin-bottom:
0cm;margin-left:53.4pt;margin-bottom:.0001pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><b><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>dirallegati</span></b><span style='font-size:12.0pt;line-height:
115%;font-variant:small-caps;text-transform:uppercase'>: la directory sul
server in cui effettuare l�upload degli allegati;</span><span style='font-variant:
small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-top:0cm;margin-right:0cm;margin-bottom:
0cm;margin-left:53.4pt;margin-bottom:.0001pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><b><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>effelog</span></b><span style='font-size:12.0pt;line-height:115%;
font-variant:small-caps;text-transform:uppercase'>: indica se attivare il log e
la relativa directory di salvataggio dei file.</span><span style='font-variant:
small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:53.4pt;margin-bottom:.0001pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>&nbsp;</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:53.4pt;margin-bottom:.0001pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>Il servizio
LDAP va inoltre attivato dal <i>Pannello di Amministrazione</i> nella tag <b>Servizi
Extra</b>.</span><span style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-top:0cm;margin-right:0cm;margin-bottom:
0cm;margin-left:21.3pt;margin-bottom:.0001pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>&nbsp;</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<span style='font-size:11.0pt;line-height:115%;font-family:"Perpetua","serif";
mso-fareast-font-family:"Times New Roman";mso-bidi-font-family:"Times New Roman";
font-variant:small-caps;color:black;text-transform:uppercase;mso-ansi-language:
IT;mso-fareast-language:IT;mso-bidi-language:AR-SA'><br clear=all
style='page-break-before:always'>
</span>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><b><span style='font-size:14.0pt;line-height:115%;
font-family:"Franklin Gothic Book","sans-serif";font-variant:small-caps;
color:#9D3511;text-transform:uppercase;letter-spacing:1.0pt'>&nbsp;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<h1 style='margin-left:21.3pt'><a name="_Toc248407500"><span style='mso-fareast-font-family:
"Times New Roman";font-variant:small-caps;text-transform:uppercase'>Work Flow
gestiti da EffE Document</span></a><span style='mso-fareast-font-family:"Times New Roman";
font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></h1>

<p class=MsoNormal style='margin-top:6.0pt;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><span style='font-size:12.0pt;line-height:115%;font-variant:
small-caps;text-transform:uppercase'>EffE Document implementa al suo interno
due tipologie di workflow per la gestione dei documento:</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-top:0cm;margin-right:0cm;margin-bottom:
10.0pt;margin-left:53.4pt;text-indent:-18.0pt'><span style='font-size:12.0pt;
line-height:115%;font-family:Symbol;font-variant:small-caps;text-transform:
uppercase'>�</span><span style='font-size:7.0pt;line-height:115%;font-family:
"Times New Roman","serif";font-variant:small-caps;text-transform:uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span><b><span style='font-size:12.0pt;line-height:115%;font-variant:small-caps;
text-transform:uppercase'>Semplice</span></b><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-top:0cm;margin-right:0cm;margin-bottom:
10.0pt;margin-left:53.4pt;text-indent:-18.0pt'><span style='font-size:12.0pt;
line-height:115%;font-family:Symbol;font-variant:small-caps;text-transform:
uppercase'>�</span><span style='font-size:7.0pt;line-height:115%;font-family:
"Times New Roman","serif";font-variant:small-caps;text-transform:uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span><b><span style='font-size:12.0pt;line-height:115%;font-variant:small-caps;
text-transform:uppercase'>Avanzato</span></b><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><b><span style='font-size:12.0pt;line-height:115%;
font-variant:small-caps;text-transform:uppercase'>&nbsp;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<h2 style='margin-left:21.3pt'><a name="_Toc248407501"><span style='mso-fareast-font-family:
"Times New Roman";font-variant:small-caps;text-transform:uppercase'>Workflow
Semplice</span></a><span style='mso-fareast-font-family:"Times New Roman";
font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></h2>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><span style='font-size:12.0pt;line-height:115%;font-variant:
small-caps;text-transform:uppercase'>Il <b>workflow semplice</b> attraversa i
seguenti stati</span><span style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 align=left
 style='mso-cellspacing:0cm;mso-yfti-tbllook:1184;mso-table-lspace:2.25pt;
 mso-table-rspace:2.25pt;mso-table-bspace:10.0pt;margin-bottom:7.75pt;
 mso-table-anchor-vertical:paragraph;mso-table-anchor-horizontal:column;
 mso-table-left:left;mso-padding-alt:0cm 0cm 0cm 0cm'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:5.25pt'>
  <td width=12 style='width:9.0pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=101 style='width:75.75pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=37 style='width:27.75pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=17 style='width:12.75pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=1 style='width:.75pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=6 style='width:4.5pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=5 style='width:3.75pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=41 style='width:30.75pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=10 style='width:7.5pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=2 style='width:1.5pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=36 style='width:27.0pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=78 style='width:58.5pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=42 style='width:31.5pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=1 style='width:.75pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=1 style='width:.75pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=51 style='width:38.25pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=3 style='width:2.25pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=186 style='width:139.5pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
 </tr>
 <tr style='mso-yfti-irow:1;height:42.75pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:42.75pt'></td>
  <td colspan=5 rowspan=4 valign=top style='padding:0cm 0cm 0cm 0cm;height:
  42.75pt'>
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
  margin-left:21.3pt;mso-element:frame;mso-element-frame-hspace:2.25pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  column;mso-height-rule:exactly'><span style='font-size:12.0pt;line-height:
  115%;font-family:"Times New Roman","serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;mso-no-proof:yes'><img border=0 width=162 height=135
  id="_x0000_i1063" src="effedoc_file/image005.png"></span><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman","serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext'><o:p></o:p></span></p>
  </td>
  <td colspan=4 style='padding:0cm 0cm 0cm 0cm;height:42.75pt'></td>
  <td colspan=3 rowspan=4 valign=top style='padding:0cm 0cm 0cm 0cm;height:
  42.75pt'>
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
  margin-left:21.3pt;mso-element:frame;mso-element-frame-hspace:2.25pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  column;mso-height-rule:exactly'><span style='font-size:12.0pt;line-height:
  115%;font-family:"Times New Roman","serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;mso-no-proof:yes'><img border=0 width=156 height=135
  id="_x0000_i1062" src="effedoc_file/image006.png"></span><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman","serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext'><o:p></o:p></span></p>
  </td>
  <td style='padding:0cm 0cm 0cm 0cm;height:42.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:42.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:42.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:42.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:42.75pt'></td>
 </tr>
 <tr style='mso-yfti-irow:2;height:18.75pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:18.75pt'></td>
  <td colspan=4 style='padding:0cm 0cm 0cm 0cm;height:18.75pt'></td>
  <td colspan=4 style='padding:0cm 0cm 0cm 0cm;height:18.75pt'></td>
  <td rowspan=11 valign=top style='padding:0cm 0cm 0cm 0cm;height:18.75pt'>
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
  margin-left:21.3pt;mso-element:frame;mso-element-frame-hspace:2.25pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  column;mso-height-rule:exactly'><span style='font-size:12.0pt;line-height:
  115%;font-family:"Times New Roman","serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;mso-no-proof:yes'><img border=0 width=186 height=266
  id="_x0000_i1061" src="effedoc_file/image007.png"></span><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman","serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext'><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:3;height:25.5pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:25.5pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:25.5pt'></td>
  <td colspan=2 valign=top style='padding:0cm 0cm 0cm 0cm;height:25.5pt'>
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
  margin-left:21.3pt;mso-element:frame;mso-element-frame-hspace:2.25pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  column;mso-height-rule:exactly'><span style='font-size:12.0pt;line-height:
  115%;font-family:"Times New Roman","serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;mso-no-proof:yes'><img border=0 width=51 height=34
  id="_x0000_i1060" src="effedoc_file/image008.png"></span><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman","serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext'><o:p></o:p></span></p>
  </td>
  <td style='padding:0cm 0cm 0cm 0cm;height:25.5pt'></td>
  <td colspan=2 style='padding:0cm 0cm 0cm 0cm;height:25.5pt'></td>
  <td valign=top style='padding:0cm 0cm 0cm 0cm;height:25.5pt'>
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
  margin-left:21.3pt;mso-element:frame;mso-element-frame-hspace:2.25pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  column;mso-height-rule:exactly'><span style='font-size:12.0pt;line-height:
  115%;font-family:"Times New Roman","serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;mso-no-proof:yes'><img border=0 width=51 height=34
  id="_x0000_i1059" src="effedoc_file/image008.png"></span><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman","serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext'><o:p></o:p></span></p>
  </td>
  <td style='padding:0cm 0cm 0cm 0cm;height:25.5pt'></td>
 </tr>
 <tr style='mso-yfti-irow:4;height:14.25pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:14.25pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:14.25pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:14.25pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:14.25pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:14.25pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:14.25pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:14.25pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:14.25pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:14.25pt'></td>
 </tr>
 <tr style='mso-yfti-irow:5;height:3.75pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
 </tr>
 <tr style='mso-yfti-irow:6;height:27.75pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:27.75pt'></td>
  <td colspan=10 style='padding:0cm 0cm 0cm 0cm;height:27.75pt'></td>
  <td valign=top style='padding:0cm 0cm 0cm 0cm;height:27.75pt'>
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
  margin-left:21.3pt;mso-element:frame;mso-element-frame-hspace:2.25pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  column;mso-height-rule:exactly'><span style='font-size:12.0pt;line-height:
  115%;font-family:"Times New Roman","serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;mso-no-proof:yes'><img border=0 width=78 height=37
  id="_x0000_i1058" src="effedoc_file/image009.png"></span><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman","serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext'><o:p></o:p></span></p>
  </td>
  <td style='padding:0cm 0cm 0cm 0cm;height:27.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:27.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:27.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:27.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:27.75pt'></td>
 </tr>
 <tr style='mso-yfti-irow:7;height:51.0pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:51.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:51.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:51.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:51.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:51.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:51.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:51.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:51.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:51.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:51.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:51.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:51.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:51.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:51.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:51.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:51.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:51.0pt'></td>
 </tr>
 <tr style='mso-yfti-irow:8;height:15.75pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:15.75pt'></td>
  <td colspan=3 rowspan=5 valign=top style='padding:0cm 0cm 0cm 0cm;height:
  15.75pt'>
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
  margin-left:21.3pt;mso-element:frame;mso-element-frame-hspace:2.25pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  column;mso-height-rule:exactly'><span style='font-size:12.0pt;line-height:
  115%;font-family:"Times New Roman","serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;mso-no-proof:yes'><img border=0 width=155 height=78
  id="_x0000_i1057" src="effedoc_file/image010.png"
  alt="Ovale: evaso&#13;&#10;(collaboratore)&#13;&#10;"></span><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman","serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext'><o:p></o:p></span></p>
  </td>
  <td colspan=6 style='padding:0cm 0cm 0cm 0cm;height:15.75pt'></td>
  <td colspan=3 rowspan=5 valign=top style='padding:0cm 0cm 0cm 0cm;height:
  15.75pt'>
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
  margin-left:21.3pt;mso-element:frame;mso-element-frame-hspace:2.25pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  column;mso-height-rule:exactly'><span style='font-size:12.0pt;line-height:
  115%;font-family:"Times New Roman","serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;mso-no-proof:yes'><img border=0 width=156 height=78
  id="_x0000_i1056" src="effedoc_file/image011.png"
  alt="Ovale: validato&#13;&#10;(collaboratore)&#13;&#10;"></span><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman","serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext'><o:p></o:p></span></p>
  </td>
  <td style='padding:0cm 0cm 0cm 0cm;height:15.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:15.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:15.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:15.75pt'></td>
 </tr>
 <tr style='mso-yfti-irow:9;height:7.5pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:7.5pt'></td>
  <td colspan=6 style='padding:0cm 0cm 0cm 0cm;height:7.5pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:7.5pt'></td>
  <td colspan=2 rowspan=2 valign=top style='padding:0cm 0cm 0cm 0cm;height:
  7.5pt'>
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
  margin-left:21.3pt;mso-element:frame;mso-element-frame-hspace:2.25pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  column;mso-height-rule:exactly'><span style='font-size:12.0pt;line-height:
  115%;font-family:"Times New Roman","serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;mso-no-proof:yes'><img border=0 width=52 height=33
  id="_x0000_i1055" src="effedoc_file/image012.png"></span><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman","serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext'><o:p></o:p></span></p>
  </td>
  <td style='padding:0cm 0cm 0cm 0cm;height:7.5pt'></td>
 </tr>
 <tr style='mso-yfti-irow:10;height:17.25pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:17.25pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:17.25pt'></td>
  <td colspan=3 rowspan=2 valign=top style='padding:0cm 0cm 0cm 0cm;height:
  17.25pt'>
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
  margin-left:21.3pt;mso-element:frame;mso-element-frame-hspace:2.25pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  column;mso-height-rule:exactly'><span style='font-size:12.0pt;line-height:
  115%;font-family:"Times New Roman","serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;mso-no-proof:yes'><img border=0 width=52 height=33
  id="_x0000_i1054" src="effedoc_file/image013.png"></span><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman","serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext'><o:p></o:p></span></p>
  </td>
  <td style='padding:0cm 0cm 0cm 0cm;height:17.25pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:17.25pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:17.25pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:17.25pt'></td>
 </tr>
 <tr style='mso-yfti-irow:11;height:7.5pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:7.5pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:7.5pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:7.5pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:7.5pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:7.5pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:7.5pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:7.5pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:7.5pt'></td>
 </tr>
 <tr style='mso-yfti-irow:12;height:10.5pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:10.5pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:10.5pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:10.5pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:10.5pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:10.5pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:10.5pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:10.5pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:10.5pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:10.5pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:10.5pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:10.5pt'></td>
 </tr>
 <tr style='mso-yfti-irow:13;height:.75pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:.75pt'></td>
 </tr>
 <tr style='mso-yfti-irow:14;mso-yfti-lastrow:yes;height:39.0pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.0pt'></td>
  <td valign=top style='padding:0cm 0cm 0cm 0cm;height:39.0pt'>
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
  margin-left:21.3pt;mso-element:frame;mso-element-frame-hspace:2.25pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  column;mso-height-rule:exactly'><span style='font-size:12.0pt;line-height:
  115%;font-family:"Times New Roman","serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;mso-no-proof:yes'><img border=0 width=37 height=52
  id="_x0000_i1053" src="effedoc_file/image014.png"></span><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman","serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext'><o:p></o:p></span></p>
  </td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.0pt'></td>
 </tr>
</table>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><span style='font-size:12.0pt;line-height:115%;font-variant:
small-caps;text-transform:uppercase'>&nbsp;</span><span style='font-variant:
small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><b><span style='font-size:14.0pt;line-height:115%;
font-family:"Franklin Gothic Book","sans-serif";font-variant:small-caps;
color:#9D3511;text-transform:uppercase;letter-spacing:1.0pt'>&nbsp;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><b><span style='font-size:14.0pt;line-height:115%;
font-family:"Franklin Gothic Book","sans-serif";font-variant:small-caps;
color:#9D3511;text-transform:uppercase;letter-spacing:1.0pt'>&nbsp;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><b><span style='font-size:14.0pt;line-height:115%;
font-family:"Franklin Gothic Book","sans-serif";font-variant:small-caps;
color:#9D3511;text-transform:uppercase;letter-spacing:1.0pt'>&nbsp;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><b><span style='font-size:14.0pt;line-height:115%;
font-family:"Franklin Gothic Book","sans-serif";font-variant:small-caps;
color:#9D3511;text-transform:uppercase;letter-spacing:1.0pt'>&nbsp;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><b><span style='font-size:14.0pt;line-height:115%;
font-family:"Franklin Gothic Book","sans-serif";font-variant:small-caps;
color:#9D3511;text-transform:uppercase;letter-spacing:1.0pt'>&nbsp;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><b><span style='font-size:14.0pt;line-height:115%;
font-family:"Franklin Gothic Book","sans-serif";font-variant:small-caps;
color:#9D3511;text-transform:uppercase;letter-spacing:1.0pt'>&nbsp;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><b><span style='font-size:14.0pt;line-height:115%;
font-family:"Franklin Gothic Book","sans-serif";font-variant:small-caps;
color:#9D3511;text-transform:uppercase;letter-spacing:1.0pt'>&nbsp;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><b><span style='font-size:14.0pt;line-height:115%;
font-family:"Franklin Gothic Book","sans-serif";font-variant:small-caps;
color:#9D3511;text-transform:uppercase;letter-spacing:1.0pt'>&nbsp;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<h1 style='margin-left:21.3pt;text-align:justify'><span style='font-size:12.0pt;
font-family:"Perpetua","serif";mso-fareast-font-family:"Times New Roman";
font-variant:small-caps;color:black;text-transform:uppercase;letter-spacing:
0pt;font-weight:normal'>&nbsp;</span><span style='mso-fareast-font-family:"Times New Roman";
font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></h1>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-variant:small-caps;
text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt'><span style='font-size:12.0pt;
line-height:115%;font-family:"Times New Roman","serif";mso-fareast-font-family:
"Times New Roman";font-variant:small-caps;color:windowtext;text-transform:uppercase'><br
clear=all style='mso-special-character:line-break'>
<o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt;text-align:justify'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Normalmente il workflow inizia con lo stato <b>assegnato</b>, ma nel
caso in cui l�area tematica di appartenenza al documento non disponga di un
responsabile questo viene posto nello stato <b>assegnazione</b> e sar� il
protocollatore ad assegnarlo</span><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt;text-align:justify'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Lo stato <b>assegnato</b> si pu� ripetere se il responsabile si
accorge che l�argomento richiesto non � di sua competenza. In tal caso lo pu�
smistare all�area tematica corretta mantenendo lo stato.</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt;text-align:justify'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Dallo stato assegnato si passa allo stato <b>lavorazione</b> in cui
il responsabile ( o pi� verosimilmente un suo collaboratore) effettua le
attivit� richieste.</span><span style='font-variant:small-caps;text-transform:
uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt;text-align:justify'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Dallo stato di lavorazione si passa allo stato <b>predisposto</b>
che riporta il documento al responsabile il quale deve validare la risposta
preparata dal collaboratore. Se la risposta � soddisfacente sposta lo stato a <b>validato</b>
rinviando il documento al collaboratore, altrimenti lo rimette nello stato di <b>lavorazione</b>
aggiungendo le note relative alle modifiche richieste.</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt;text-align:justify'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Nello stato validato il collaboratore eventualmente invia la
risposta preparata e pone lo stato ad <b>evaso</b> chiudendo di fatto la
richiesta.</span><span style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<h2 style='margin-left:21.3pt'><a name="_Toc248407502"><span style='mso-fareast-font-family:
"Times New Roman";font-variant:small-caps;text-transform:uppercase'>Workflow
Avanzato</span></a><span style='mso-fareast-font-family:"Times New Roman";
font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></h2>

<p class=MsoNormal style='margin-top:6.0pt;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><span style='font-size:12.0pt;line-height:115%;font-variant:
small-caps;text-transform:uppercase'>Il <b>workflow avanzato</b> attraversa i
seguenti stati</span><span style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><span style='font-size:12.0pt;line-height:115%;font-variant:
small-caps;text-transform:uppercase'>&nbsp;</span><span style='font-variant:
small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 align=left
 style='mso-cellspacing:0cm;mso-yfti-tbllook:1184;mso-table-lspace:2.25pt;
 mso-table-rspace:2.25pt;mso-table-bspace:10.0pt;margin-bottom:7.75pt;
 mso-table-anchor-vertical:paragraph;mso-table-anchor-horizontal:column;
 mso-table-left:left;mso-padding-alt:0cm 0cm 0cm 0cm'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:5.25pt'>
  <td width=12 style='width:9.0pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=39 style='width:29.25pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=36 style='width:27.0pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=87 style='width:65.25pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=5 style='width:3.75pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=51 style='width:38.25pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=2 style='width:1.5pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
  <td width=382 style='width:286.5pt;padding:0cm 0cm 0cm 0cm;height:5.25pt'></td>
 </tr>
 <tr style='mso-yfti-irow:1;height:61.5pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:61.5pt'></td>
  <td colspan=3 rowspan=3 valign=top style='padding:0cm 0cm 0cm 0cm;height:
  61.5pt'>
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
  margin-left:21.3pt;mso-element:frame;mso-element-frame-hspace:2.25pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  column;mso-height-rule:exactly'><span style='font-size:12.0pt;line-height:
  115%;font-family:"Times New Roman","serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;mso-no-proof:yes'><img border=0 width=162 height=135
  id="_x0000_i1052" src="effedoc_file/image005.png"></span><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman","serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext'><o:p></o:p></span></p>
  </td>
  <td colspan=3 style='padding:0cm 0cm 0cm 0cm;height:61.5pt'></td>
  <td rowspan=6 valign=top style='padding:0cm 0cm 0cm 0cm;height:61.5pt'>
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
  margin-left:21.3pt;mso-element:frame;mso-element-frame-hspace:2.25pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  column;mso-height-rule:exactly'><span style='font-size:12.0pt;line-height:
  115%;font-family:"Times New Roman","serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;mso-no-proof:yes'><img border=0 width=382 height=424
  id="_x0000_i1051" src="effedoc_file/image015.png"></span><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman","serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext'><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:2;height:25.5pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:25.5pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:25.5pt'></td>
  <td valign=top style='padding:0cm 0cm 0cm 0cm;height:25.5pt'>
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
  margin-left:21.3pt;mso-element:frame;mso-element-frame-hspace:2.25pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  column;mso-height-rule:exactly'><span style='font-size:12.0pt;line-height:
  115%;font-family:"Times New Roman","serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;mso-no-proof:yes'><img border=0 width=51 height=34
  id="_x0000_i1050" src="effedoc_file/image008.png"></span><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman","serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext'><o:p></o:p></span></p>
  </td>
  <td style='padding:0cm 0cm 0cm 0cm;height:25.5pt'></td>
 </tr>
 <tr style='mso-yfti-irow:3;height:14.25pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:14.25pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:14.25pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:14.25pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:14.25pt'></td>
 </tr>
 <tr style='mso-yfti-irow:4;height:174.0pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:174.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:174.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:174.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:174.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:174.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:174.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:174.0pt'></td>
 </tr>
 <tr style='mso-yfti-irow:5;height:39.75pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.75pt'></td>
  <td valign=top style='padding:0cm 0cm 0cm 0cm;height:39.75pt'>
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
  margin-left:21.3pt;mso-element:frame;mso-element-frame-hspace:2.25pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  column;mso-height-rule:exactly'><span style='font-size:12.0pt;line-height:
  115%;font-family:"Times New Roman","serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;mso-no-proof:yes'><img border=0 width=36 height=53
  id="_x0000_i1049" src="effedoc_file/image016.png"></span><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman","serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext'><o:p></o:p></span></p>
  </td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:39.75pt'></td>
 </tr>
 <tr style='mso-yfti-irow:6;mso-yfti-lastrow:yes;height:3.0pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.0pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:3.0pt'></td>
 </tr>
</table>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><span style='font-size:12.0pt;line-height:115%;font-variant:
small-caps;text-transform:uppercase'>&nbsp;</span><span style='font-variant:
small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><b><span style='font-size:14.0pt;line-height:115%;
font-family:"Franklin Gothic Book","sans-serif";font-variant:small-caps;
color:#9D3511;text-transform:uppercase;letter-spacing:1.0pt'>&nbsp;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><b><span style='font-size:14.0pt;line-height:115%;
font-family:"Franklin Gothic Book","sans-serif";font-variant:small-caps;
color:#9D3511;text-transform:uppercase;letter-spacing:1.0pt'>&nbsp;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><b><span style='font-size:14.0pt;line-height:115%;
font-family:"Franklin Gothic Book","sans-serif";font-variant:small-caps;
color:#9D3511;text-transform:uppercase;letter-spacing:1.0pt'>&nbsp;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><b><span style='font-size:14.0pt;line-height:115%;
font-family:"Franklin Gothic Book","sans-serif";font-variant:small-caps;
color:#9D3511;text-transform:uppercase;letter-spacing:1.0pt'>&nbsp;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><b><span style='font-size:14.0pt;line-height:115%;
font-family:"Franklin Gothic Book","sans-serif";font-variant:small-caps;
color:#9D3511;text-transform:uppercase;letter-spacing:1.0pt'>&nbsp;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><b><span style='font-size:14.0pt;line-height:115%;
font-family:"Franklin Gothic Book","sans-serif";font-variant:small-caps;
color:#9D3511;text-transform:uppercase;letter-spacing:1.0pt'>&nbsp;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><b><span style='font-size:14.0pt;line-height:115%;
font-family:"Franklin Gothic Book","sans-serif";font-variant:small-caps;
color:#9D3511;text-transform:uppercase;letter-spacing:1.0pt'>&nbsp;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><b><span style='font-size:14.0pt;line-height:115%;
font-family:"Franklin Gothic Book","sans-serif";font-variant:small-caps;
color:#9D3511;text-transform:uppercase;letter-spacing:1.0pt'>&nbsp;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<h1 style='margin-left:21.3pt'><span style='mso-fareast-font-family:"Times New Roman";
font-variant:small-caps;text-transform:uppercase'>&nbsp;<o:p></o:p></span></h1>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><span style='font-variant:small-caps;text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 align=left
 style='mso-cellspacing:0cm;mso-yfti-tbllook:1184;mso-table-lspace:2.25pt;
 mso-table-rspace:2.25pt;mso-table-bspace:10.0pt;margin-bottom:7.75pt;
 mso-table-anchor-vertical:paragraph;mso-table-anchor-horizontal:column;
 mso-table-left:left;mso-padding-alt:0cm 0cm 0cm 0cm'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:3.75pt'>
  <td width=22 style='width:16.5pt;padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td width=155 style='width:116.25pt;padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td width=1 style='width:.75pt;padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td width=52 style='width:39.0pt;padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td width=9 style='width:6.75pt;padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
  <td width=156 style='width:117.0pt;padding:0cm 0cm 0cm 0cm;height:3.75pt'></td>
 </tr>
 <tr style='mso-yfti-irow:1;height:6.75pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:6.75pt'></td>
  <td rowspan=4 valign=top style='padding:0cm 0cm 0cm 0cm;height:6.75pt'>
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
  margin-left:21.3pt;mso-element:frame;mso-element-frame-hspace:2.25pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  column;mso-height-rule:exactly'><span style='font-size:12.0pt;line-height:
  115%;font-family:"Times New Roman","serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;mso-no-proof:yes'><img border=0 width=155 height=78
  id="_x0000_i1048" src="effedoc_file/image017.png"
  alt="Ovale: evaso&#13;&#10;(collaboratore)&#13;&#10;"></span><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman","serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext'><o:p></o:p></span></p>
  </td>
  <td style='padding:0cm 0cm 0cm 0cm;height:6.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:6.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:6.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:6.75pt'></td>
 </tr>
 <tr style='mso-yfti-irow:2;height:14.25pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:14.25pt'></td>
  <td colspan=3 style='padding:0cm 0cm 0cm 0cm;height:14.25pt'></td>
  <td rowspan=4 valign=top style='padding:0cm 0cm 0cm 0cm;height:14.25pt'>
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
  margin-left:21.3pt;mso-element:frame;mso-element-frame-hspace:2.25pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  column;mso-height-rule:exactly'><span style='font-size:12.0pt;line-height:
  115%;font-family:"Times New Roman","serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;mso-no-proof:yes'><img border=0 width=156 height=78
  id="_x0000_i1047" src="effedoc_file/image018.png"
  alt="Ovale: autorizzato&#13;&#10;(collaboratore)&#13;&#10;"></span><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman","serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext'><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:3;height:24.75pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:24.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:24.75pt'></td>
  <td valign=top style='padding:0cm 0cm 0cm 0cm;height:24.75pt'>
  <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
  margin-left:21.3pt;mso-element:frame;mso-element-frame-hspace:2.25pt;
  mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:
  column;mso-height-rule:exactly'><span style='font-size:12.0pt;line-height:
  115%;font-family:"Times New Roman","serif";mso-fareast-font-family:"Times New Roman";
  color:windowtext;mso-no-proof:yes'><img border=0 width=52 height=33
  id="_x0000_i1046" src="effedoc_file/image019.png"></span><span
  style='font-size:12.0pt;line-height:115%;font-family:"Times New Roman","serif";
  mso-fareast-font-family:"Times New Roman";color:windowtext'><o:p></o:p></span></p>
  </td>
  <td style='padding:0cm 0cm 0cm 0cm;height:24.75pt'></td>
 </tr>
 <tr style='mso-yfti-irow:4;height:12.75pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:12.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:12.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:12.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:12.75pt'></td>
 </tr>
 <tr style='mso-yfti-irow:5;mso-yfti-lastrow:yes;height:6.75pt'>
  <td style='padding:0cm 0cm 0cm 0cm;height:6.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:6.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:6.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:6.75pt'></td>
  <td style='padding:0cm 0cm 0cm 0cm;height:6.75pt'></td>
 </tr>
</table>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-variant:small-caps;
text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-variant:small-caps;
text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-variant:small-caps;
text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='mso-fareast-font-family:
"Times New Roman";font-variant:small-caps;text-transform:uppercase'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
margin-left:21.3pt;margin-bottom:.0001pt'><span style='font-size:12.0pt;
line-height:115%;font-family:"Times New Roman","serif";mso-fareast-font-family:
"Times New Roman";font-variant:small-caps;color:windowtext;text-transform:uppercase'><br
clear=all style='mso-special-character:line-break'>
<o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:35.4pt;text-align:justify'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Normalmente il workflow inizia con lo stato <b>assegnato</b>, ma nel
caso in cui l�area tematica di appartenenza al documento non disponga di un
responsabile questo viene posto nello stato <b>assegnazione</b> e sar� il
protocollatore ad assegnarlo.</span><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:35.4pt;text-align:justify'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Lo stato <b>assegnato</b> si pu� ripetere se il responsabile si
accorge che l�argomento richiesto non � di sua competenza. In tal caso lo pu�
smistare all�area tematica corretta mantenendo lo stato.</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:35.4pt;text-align:justify'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Dallo stato assegnato si passa allo stato <b>lavorazione</b> in cui
il responsabile ( o pi� verosimilmente un suo collaboratore) effettua le
attivit� richieste.</span><span style='font-variant:small-caps;text-transform:
uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:35.4pt;text-align:justify'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Dallo stato di lavorazione si passa allo stato <b>predisposto</b>
che riporta il documento al responsabile il quale deve validare la risposta
preparata dal collaboratore. Se la risposta � soddisfacente sposta lo stato a <b>validato</b>
inviando il documento al responsabile di Servizio per la verifica finale,
altrimenti lo rimette nello stato di <b>lavorazione</b> aggiungendo le note
relative alle modifiche richieste.</span><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:35.4pt;text-align:justify'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Dallo stato validato il responsabile di Servizio pu� porre il
documento nello stato <b>autorizzato</b> e quindi rinviarlo al collaboratore,
oppure rimetterlo nello stato <b>predisposto</b> e rinviarlo al responsabile di
area tematica.</span><span style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:35.4pt;text-align:justify'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Nello stato autorizzato il collaboratore eventualmente invia la
risposta preparata e pone lo stato ad <b>evaso</b> chiudendo di fatto la
richiesta.</span><span style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<h1 style='margin-left:21.3pt'><span style='mso-fareast-font-family:"Times New Roman";
font-variant:small-caps;text-transform:uppercase'>&nbsp;<o:p></o:p></span></h1>

<h1 style='margin-left:21.3pt'><a name="_Toc248407503"><span style='mso-fareast-font-family:
"Times New Roman";font-variant:small-caps;text-transform:uppercase'>Generazione
Numero di Protocollo</span></a><span style='mso-fareast-font-family:"Times New Roman";
font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></h1>

<p class=MsoNormal style='margin-top:6.0pt;margin-right:0cm;margin-bottom:8.0pt;
margin-left:21.3pt'><span style='font-size:12.0pt;line-height:115%;font-variant:
small-caps;text-transform:uppercase'>EffE Document genera per ogni nuovo
documento un protocollo univoco simile al seguente:</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='margin-left:21.3pt;text-align:center'><b><span
style='font-size:16.0pt;line-height:115%;font-variant:small-caps;color:#0070C0;
text-transform:uppercase'>CM</span></b><b><span style='font-size:16.0pt;
line-height:115%;font-variant:small-caps;color:#00B050;text-transform:uppercase'>35</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>composto da
2 elementi:</span><span style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>1.</span><span style='font-size:7.0pt;line-height:115%;font-family:
"Times New Roman","serif";font-variant:small-caps;text-transform:uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span><span style='font-size:12.0pt;line-height:115%;font-variant:small-caps;
text-transform:uppercase'>Sigla dell�Ente a cui viene sottoposto il documento,
nell�esempio <b>CM</b> (Comune);</span><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>2.</span><span style='font-size:7.0pt;line-height:115%;font-family:
"Times New Roman","serif";font-variant:small-caps;text-transform:uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span><span style='font-size:12.0pt;line-height:115%;font-variant:small-caps;
text-transform:uppercase'>Numero progressivo, nell�esempio <b>35</b>;</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>&nbsp;</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>Il
protocollo progressivo per ingresso ed uscita, quindi avr�:</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><b><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>protocollo
25 in ingresso</span></b><span style='font-size:12.0pt;line-height:115%;
font-variant:small-caps;text-transform:uppercase'> e <b>protocollo 25 in uscita</b></span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<span style='font-size:11.0pt;line-height:115%;font-family:"Perpetua","serif";
mso-fareast-font-family:"Times New Roman";mso-bidi-font-family:"Times New Roman";
font-variant:small-caps;color:black;text-transform:uppercase;mso-ansi-language:
IT;mso-fareast-language:IT;mso-bidi-language:AR-SA'><br clear=all
style='page-break-before:always'>
</span>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><b><span style='font-size:14.0pt;line-height:115%;
font-family:"Franklin Gothic Book","sans-serif";font-variant:small-caps;
color:#9D3511;text-transform:uppercase;letter-spacing:1.0pt'>&nbsp;</span></b><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<h1 style='margin-left:21.3pt'><a name="_Toc248407504"><span style='mso-fareast-font-family:
"Times New Roman";font-variant:small-caps;text-transform:uppercase'>Sistema di Back
End</span></a><span style='mso-fareast-font-family:"Times New Roman";
font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></h1>

<p class=MsoNormal align=center style='margin-left:21.3pt;text-align:center;
page-break-after:avoid'><span style='font-variant:small-caps;text-transform:
uppercase;mso-no-proof:yes'><img border=0 width=481 height=345 id="_x0000_i1045"
src="effedoc_file/image020.png" alt="backend_login.png"></span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoCaption align=center style='margin-left:21.3pt;text-align:center'><span
style='text-transform:uppercase'>Figura 2- Schermata di login<o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-variant:small-caps;
text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>GR prevede <b>6</b>
tipologie di utenti di back - end:</span><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>&nbsp;</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<div align=center>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
 style='border-collapse:collapse;mso-yfti-tbllook:1184;mso-padding-alt:0cm 0cm 0cm 0cm'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
  <td width=64 valign=top style='width:47.95pt;border:none;border-bottom:solid #A28E6A 3.0pt;
  background:white;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-left:21.3pt;line-height:normal'><b><span
  style='font-size:12.0pt;font-family:"Franklin Gothic Book","sans-serif"'>&nbsp;</span></b></p>
  </td>
  <td width=208 valign=top style='width:155.9pt;border:none;border-bottom:solid #A28E6A 3.0pt;
  background:white;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-left:21.3pt;line-height:normal'><b><span
  style='font-size:12.0pt;font-family:"Franklin Gothic Book","sans-serif"'>Utente</span></b></p>
  </td>
  <td width=233 valign=top style='width:174.75pt;border:none;border-bottom:
  solid #A28E6A 3.0pt;background:white;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-left:21.3pt;line-height:normal'><b><span
  style='font-size:12.0pt;font-family:"Franklin Gothic Book","sans-serif"'>Funzionalit�</span></b></p>
  </td>
  <td width=114 valign=top style='width:85.75pt;border:none;border-bottom:solid #A28E6A 3.0pt;
  background:white;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=right style='margin-left:21.3pt;text-align:right;
  line-height:normal'><b><span style='font-size:12.0pt;font-family:"Franklin Gothic Book","sans-serif"'>Scope</span></b></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1'>
  <td width=64 valign=top style='width:47.95pt;border:none;border-right:solid #A28E6A 1.0pt;
  background:white;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=center style='margin-left:21.3pt;text-align:center;
  line-height:normal'><span style='font-size:12.0pt;font-family:"Franklin Gothic Book","sans-serif";
  mso-no-proof:yes'><img border=0 width=38 height=38 id="_x0000_i1044"
  src="effedoc_file/image021.png"></span></p>
  </td>
  <td width=208 valign=top style='width:155.9pt;background:#E8E2DA;padding:
  0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-left:21.3pt;line-height:normal'><b><span
  style='font-size:10.0pt;font-family:"Franklin Gothic Book","sans-serif"'>Amministratore</span></b></p>
  </td>
  <td width=233 valign=top style='width:174.75pt;background:#E8E2DA;padding:
  0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-left:21.3pt;line-height:normal'><span
  style='font-family:"Franklin Gothic Book","sans-serif"'>Settare la
  configurazione della web application ma non accedere ai documento inseriti
  (unico)</span></p>
  </td>
  <td width=114 valign=top style='width:85.75pt;border:none;border-right:solid #A28E6A 1.0pt;
  background:#E8E2DA;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=right style='margin-left:21.3pt;text-align:right;
  line-height:normal'><i><span style='font-family:"Franklin Gothic Book","sans-serif"'>Web
  Application</span></i></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:2'>
  <td width=64 valign=top style='width:47.95pt;border:none;border-right:solid #A28E6A 1.0pt;
  background:white;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=center style='margin-left:21.3pt;text-align:center;
  line-height:normal'><i style='mso-bidi-font-style:normal'><span
  style='font-size:12.0pt;font-family:"Franklin Gothic Book","sans-serif";
  mso-no-proof:yes'><img border=0 width=38 height=38 id="_x0000_i1043"
  src="effedoc_file/image022.png"></span></i></p>
  </td>
  <td width=208 valign=top style='width:155.9pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-left:21.3pt;line-height:normal'><b><i><span
  style='font-size:10.0pt;font-family:"Franklin Gothic Book","sans-serif"'>Responsabile
  Servizio</span></i></b></p>
  </td>
  <td width=233 valign=top style='width:174.75pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-left:21.3pt;line-height:normal'><span
  style='font-family:"Franklin Gothic Book","sans-serif"'>Controllo della richiesta
  relativa al servizio di cui � responsabile</span></p>
  </td>
  <td width=114 valign=top style='width:85.75pt;border:none;border-right:solid #A28E6A 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=right style='margin-left:21.3pt;text-align:right;
  line-height:normal'><i><span style='font-family:"Franklin Gothic Book","sans-serif"'>Servizio</span></i></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:3'>
  <td width=64 valign=top style='width:47.95pt;border:none;border-right:solid #A28E6A 1.0pt;
  background:white;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=center style='margin-left:21.3pt;text-align:center;
  line-height:normal'><span style='font-size:12.0pt;font-family:"Franklin Gothic Book","sans-serif";
  mso-no-proof:yes'><img border=0 width=38 height=38 id="_x0000_i1042"
  src="effedoc_file/image023.png"></span></p>
  </td>
  <td width=208 valign=top style='width:155.9pt;background:#E8E2DA;padding:
  0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-left:21.3pt;line-height:normal'><b><span
  style='font-size:10.0pt;font-family:"Franklin Gothic Book","sans-serif"'>Protocollatore</span></b></p>
  </td>
  <td width=233 valign=top style='width:174.75pt;background:#E8E2DA;padding:
  0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-left:21.3pt;text-align:justify;line-height:
  normal'><span style='font-family:"Franklin Gothic Book","sans-serif"'>Visualizzazione
  di tutti i documento relativi all�Servizio e protocollare le richieste non
  pervenute attraverso il web (<i>E-Mail</i>, <i>Fax</i>, <i>Posta Ordinaria</i>,
  <i>Posta Raccomandata</i>, <i>Telefono</i>)</span></p>
  </td>
  <td width=114 valign=top style='width:85.75pt;border:none;border-right:solid #A28E6A 1.0pt;
  background:#E8E2DA;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=right style='margin-left:21.3pt;text-align:right;
  line-height:normal'><i><span style='font-family:"Franklin Gothic Book","sans-serif"'>Servizio</span></i></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:4'>
  <td width=64 valign=top style='width:47.95pt;border:none;border-right:solid #A28E6A 1.0pt;
  background:white;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=center style='margin-left:21.3pt;text-align:center;
  line-height:normal'><span style='font-size:12.0pt;font-family:"Franklin Gothic Book","sans-serif";
  mso-no-proof:yes'><img border=0 width=29 height=38 id="_x0000_i1041"
  src="effedoc_file/image024.png"></span></p>
  </td>
  <td width=208 valign=top style='width:155.9pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-left:21.3pt;line-height:normal'><b><span
  style='font-size:10.0pt;font-family:"Franklin Gothic Book","sans-serif"'>Collaboratore</span></b></p>
  </td>
  <td width=233 valign=top style='width:174.75pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-left:21.3pt;text-align:justify;line-height:
  normal'><span style='font-family:"Franklin Gothic Book","sans-serif"'>Assolve
  le procedure per giungere all�evasione del documento</span></p>
  </td>
  <td width=114 valign=top style='width:85.75pt;border:none;border-right:solid #A28E6A 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=right style='margin-left:21.3pt;text-align:right;
  line-height:normal'><i><span style='font-family:"Franklin Gothic Book","sans-serif"'>Servizio</span></i></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:5'>
  <td width=64 valign=top style='width:47.95pt;border:none;border-right:solid #A28E6A 1.0pt;
  background:white;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=center style='margin-left:21.3pt;text-align:center;
  line-height:normal'><span style='font-size:12.0pt;font-family:"Franklin Gothic Book","sans-serif";
  mso-no-proof:yes'><img border=0 width=38 height=38 id="_x0000_i1040"
  src="effedoc_file/image025.png"></span></p>
  </td>
  <td width=208 valign=top style='width:155.9pt;background:#E8E2DA;padding:
  0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-left:21.3pt;line-height:normal'><b><span
  style='font-size:10.0pt;font-family:"Franklin Gothic Book","sans-serif";
  color:windowtext'>Supervisore</span></b></p>
  </td>
  <td width=233 valign=top style='width:174.75pt;background:#E8E2DA;padding:
  0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-left:21.3pt;line-height:normal'><span
  style='font-family:"Franklin Gothic Book","sans-serif";color:windowtext'>Approva
  l�evasione nel caso la richiesta segua un flusso avanzato</span></p>
  </td>
  <td width=114 valign=top style='width:85.75pt;border:none;border-right:solid #A28E6A 1.0pt;
  background:#E8E2DA;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=right style='margin-left:21.3pt;text-align:right;
  line-height:normal'><i><span style='font-family:"Franklin Gothic Book","sans-serif";
  color:windowtext'>Ente</span></i></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:6;mso-yfti-lastrow:yes'>
  <td width=64 valign=top style='width:47.95pt;border:none;border-right:solid #A28E6A 1.0pt;
  background:white;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=center style='margin-left:21.3pt;text-align:center;
  line-height:normal'><span style='font-size:12.0pt;font-family:"Franklin Gothic Book","sans-serif";
  mso-no-proof:yes'><img border=0 width=38 height=38 id="_x0000_i1039"
  src="effedoc_file/image026.png"></span></p>
  </td>
  <td width=208 valign=top style='width:155.9pt;border:none;border-bottom:solid #A28E6A 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-left:21.3pt;line-height:normal'><b><span
  style='font-size:10.0pt;font-family:"Franklin Gothic Book","sans-serif"'>Visualizzatore
  Report</span></b></p>
  </td>
  <td width=233 valign=top style='width:174.75pt;border:none;border-bottom:
  solid #A28E6A 1.0pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-left:21.3pt;text-align:justify;line-height:
  normal'><span style='font-family:"Franklin Gothic Book","sans-serif"'>Visiona
  i Report di attivit�</span></p>
  <p class=MsoNormal style='margin-left:21.3pt;line-height:normal'><span
  style='font-family:"Franklin Gothic Book","sans-serif"'>&nbsp;</span></p>
  </td>
  <td width=114 valign=top style='width:85.75pt;border-top:none;border-left:
  none;border-bottom:solid #A28E6A 1.0pt;border-right:solid #A28E6A 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=right style='margin-left:21.3pt;text-align:right;
  line-height:normal'><i><span style='font-family:"Franklin Gothic Book","sans-serif"'>Web
  Application</span></i></p>
  </td>
 </tr>
</table>

</div>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-variant:small-caps;
text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>Ogni utente pu�
accedere alle proprie funzionalit� effettuando il log-in dall�url:</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt;text-align:justify;text-indent:
35.45pt'><b><span lang=EN-US style='font-size:12.0pt;line-height:115%;
font-variant:small-caps;text-transform:uppercase;mso-ansi-language:EN-US'>http://www.mywebsite:8080/effedocument/backoffice/
</span></b><span lang=EN-US style='font-variant:small-caps;text-transform:uppercase;
mso-ansi-language:EN-US'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt;text-align:justify;text-indent:
35.45pt'><span lang=EN-US style='font-size:12.0pt;line-height:115%;font-variant:
small-caps;text-transform:uppercase;mso-ansi-language:EN-US'>oppure<b>
http://www.mywebsite:8080/effedocument/backoffice/index.php</b></span><span
lang=EN-US style='font-variant:small-caps;text-transform:uppercase;mso-ansi-language:
EN-US'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt;text-align:justify;text-indent:
35.45pt'><span lang=EN-US style='font-size:12.0pt;line-height:115%;font-variant:
small-caps;text-transform:uppercase;mso-ansi-language:EN-US'>&nbsp;</span><span
lang=EN-US style='font-variant:small-caps;text-transform:uppercase;mso-ansi-language:
EN-US'><o:p></o:p></span></p>

<h2 style='margin-left:21.3pt'><span style='mso-fareast-font-family:"Times New Roman";
font-variant:small-caps;text-transform:uppercase;mso-no-proof:yes'><img
border=0 width=38 height=38 id="_x0000_i1038" src="effedoc_file/image021.png"></span><span
style='mso-fareast-font-family:"Times New Roman";font-variant:small-caps;
text-transform:uppercase'>&nbsp;<a name="_Toc248407505">Amministratore</a><o:p></o:p></span></h2>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>&nbsp;</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>Dopo aver
effettuato il login, l�amministratore pu�:</span><span style='font-variant:
small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Amministrare le aree tematiche (</span></i><span style='font-size:
12.0pt;line-height:115%;font-variant:small-caps;text-transform:uppercase'>aggiunta,
modifica, attivazione/disattivazione, settaggio della tipologia di procedura);</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Gestire le Agenzie</span></i><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'> (aggiunta,
modifica, attivazione/disattivazione);</span><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Gestire i Servizi Extra, Avvisi e Faq </span></i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>(aggiunta, eliminazione);</span><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Visualizzare gli Utenti che hanno aperto almeno un documento</span></i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>;</span><span style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Gestire gli operatori </span></i><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>(aggiunta,
modifica, attivazione/disattivazione, modifica del ruolo e dell�area tematica);</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='margin-left:21.3pt;text-align:center;
page-break-after:avoid'><span style='font-variant:small-caps;text-transform:
uppercase;mso-no-proof:yes'><img border=0 width=639 height=281 id="_x0000_i1037"
src="effedoc_file/image027.png" alt="backend_servizi.png"></span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoCaption align=center style='margin-left:21.3pt;text-align:center'><span
style='font-size:10.0pt;text-transform:uppercase'>Figura 3 - Schermata di
amministrazione tipo</span><span style='text-transform:uppercase'><o:p></o:p></span></p>

<span style='font-size:11.0pt;line-height:115%;font-family:"Perpetua","serif";
mso-fareast-font-family:"Times New Roman";mso-bidi-font-family:"Times New Roman";
font-variant:small-caps;color:black;text-transform:uppercase;mso-ansi-language:
IT;mso-fareast-language:IT;mso-bidi-language:AR-SA'><br clear=all
style='page-break-before:always'>
</span>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><span style='font-variant:small-caps;text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<h2 style='margin-left:21.3pt'><span style='mso-fareast-font-family:"Times New Roman";
font-variant:small-caps;text-transform:uppercase;mso-no-proof:yes'><img
border=0 width=38 height=38 id="_x0000_i1036" src="effedoc_file/image028.png"></span><span
style='mso-fareast-font-family:"Times New Roman";font-variant:small-caps;
text-transform:uppercase'>&nbsp;<a name="_Toc248407506">Responsabile Area
Tematica</a><o:p></o:p></span></h2>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>&nbsp;</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>Dopo aver
effettuato il login, il Responsabile di Area Tematica pu�:</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Visualizzare i documento dell�Area Tematica;</span></i><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Modificare l�Area Tematica del Documento</span></i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'> <i>se si trova nello stato Assegnato</i> (quindi ancora non preso
il lavorazione);</span><span style='font-variant:small-caps;text-transform:
uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Variarne lo Stato</span></i><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>;</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Visualizzare lo storico;</span></i><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Assegnarlo ad un collaboratore;</span></i><span style='font-variant:
small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Consultare gli eventuali allegati;</span></i><span style='font-variant:
small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Inviare la risposta se nello stato Evaso;</span></i><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Effettuare filtraggi e ricerche tra i vari documento</span></i><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><i><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>&nbsp;</span></i><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt;page-break-after:avoid'><span
style='font-variant:small-caps;text-transform:uppercase;mso-no-proof:yes'><img
border=0 width=605 height=180 id="_x0000_i1035" src="effedoc_file/image029.png"
alt="backend_protocollo.png"></span><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoCaption align=center style='margin-left:21.3pt;text-align:center'><span
style='text-transform:uppercase'>Figura 4 - Schermata Tipo Di Gestione Dei
Documenti Protocollati<o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><span style='font-variant:small-caps;text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><span style='font-variant:small-caps;text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<h2 style='margin-left:21.3pt'><span style='mso-fareast-font-family:"Times New Roman";
font-variant:small-caps;text-transform:uppercase;mso-no-proof:yes'><img
border=0 width=38 height=38 id="_x0000_i1034" src="effedoc_file/image023.png"></span><span
style='mso-fareast-font-family:"Times New Roman";font-variant:small-caps;
text-transform:uppercase'>&nbsp;<a name="_Toc248407507">Protocollatore</a><o:p></o:p></span></h2>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>&nbsp;</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>Dopo aver effettuato
il login, il Protocollatore pu�:</span><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Visualizzare i documento dell�Servizio</span></i><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-family:Symbol;font-variant:small-caps;text-transform:uppercase'>�</span><span
style='font-size:7.0pt;line-height:115%;font-family:"Times New Roman","serif";
font-variant:small-caps;text-transform:uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span><i><span style='font-size:12.0pt;line-height:115%;font-variant:small-caps;
text-transform:uppercase'>Protocollare una nuova richiesta</span></i><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Assegnare un documento;</span></i><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Consultare gli eventuali allegati;</span></i><span style='font-variant:
small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Effettuare filtraggi e ricerche tra i vari documento</span></i><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Visualizzare lo storico;</span></i><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:21.3pt'><i><span style='font-size:
12.0pt;line-height:115%;font-variant:small-caps;text-transform:uppercase'>&nbsp;</span></i><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='margin-left:21.3pt;text-align:center;
page-break-after:avoid'><span style='font-variant:small-caps;text-transform:
uppercase;mso-no-proof:yes'><img border=0 width=605 height=575 id="_x0000_i1033"
src="effedoc_file/image030.png" alt="backend_ingproto.png"></span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoCaption align=center style='margin-left:21.3pt;text-align:center'><span
style='text-transform:uppercase'>Figura 5- Schermata di protocollazione<o:p></o:p></span></p>

<h2 style='margin-left:21.3pt'><span style='mso-fareast-font-family:"Times New Roman";
font-variant:small-caps;text-transform:uppercase;mso-no-proof:yes'><img
border=0 width=29 height=38 id="_x0000_i1032" src="effedoc_file/image031.png"></span><span
style='mso-fareast-font-family:"Times New Roman";font-variant:small-caps;
text-transform:uppercase'>&nbsp;<a name="_Toc248407508">Collaboratore</a><o:p></o:p></span></h2>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>&nbsp;</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>Dopo aver
effettuato il login, il <b>Collaboratore</b>:</span><span style='font-variant:
small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Visualizzare i documento assegnati</span></i><span style='font-variant:
small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Consultare gli eventuali allegati;</span></i><span style='font-variant:
small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Effettuare filtraggi e ricerche tra i vari documento</span></i><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Preparare la risposta</span></i><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Inviare la risposta una volta validata/autorizzata</span></i><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-family:Symbol;font-variant:small-caps;
text-transform:uppercase'>�</span><span style='font-size:7.0pt;line-height:
115%;font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Visualizzare lo storico;</span></i><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<h2 style='margin-left:21.3pt'><span style='mso-fareast-font-family:"Times New Roman";
font-variant:small-caps;text-transform:uppercase;mso-no-proof:yes'><img
border=0 width=38 height=38 id="_x0000_i1031" src="effedoc_file/image025.png"></span><span
style='mso-fareast-font-family:"Times New Roman";font-variant:small-caps;
text-transform:uppercase'>&nbsp;<a name="_Toc248407509">Responsabile di
Servizio</a><o:p></o:p></span></h2>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>&nbsp;</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>Il <b>Responsabile
di Servizio</b> interviene solo nel Workflow Avanzato per l�autorizzazione
all�invio della risposta. Come negli altri casi � ovviamente richiesto il
login.</span><span style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-variant:small-caps;
text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-variant:small-caps;
text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<h2 style='margin-left:21.3pt'><span style='mso-fareast-font-family:"Times New Roman";
font-variant:small-caps;text-transform:uppercase;mso-no-proof:yes'><img
border=0 width=38 height=38 id="_x0000_i1030" src="effedoc_file/image032.png"></span><span
style='mso-fareast-font-family:"Times New Roman";font-variant:small-caps;
text-transform:uppercase'>&nbsp;<a name="_Toc248407510">Visualizzatore Report</a><o:p></o:p></span></h2>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>&nbsp;</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>Dopo aver
effettuato il login, il <b>Visualizzatore Report</b> pu� visualizzare e
filtrare i report statistici sui dati presenti nel sistema.</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-variant:small-caps;
text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<p class=MsoNormal align=center style='margin-left:21.3pt;text-align:center;
page-break-after:avoid'><span style='font-variant:small-caps;text-transform:
uppercase;mso-no-proof:yes'><img border=0 width=654 height=112 id="_x0000_i1029"
src="effedoc_file/image033.png" alt=report.jpg></span><span style='font-variant:
small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoCaption align=center style='margin-left:21.3pt;text-align:center'><span
style='text-transform:uppercase'>Figura 6 - Esempio di report<o:p></o:p></span></p>

<span style='font-size:11.0pt;line-height:115%;font-family:"Perpetua","serif";
mso-fareast-font-family:"Times New Roman";mso-bidi-font-family:"Times New Roman";
font-variant:small-caps;color:black;text-transform:uppercase;mso-ansi-language:
IT;mso-fareast-language:IT;mso-bidi-language:AR-SA'><br clear=all
style='page-break-before:always'>
</span>

<p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:10.0pt;
margin-left:21.3pt'><span style='font-variant:small-caps;text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<h1 style='margin-left:21.3pt'><a name="_Toc248407511"><span style='mso-fareast-font-family:
"Times New Roman";font-variant:small-caps;text-transform:uppercase'>Sistema di
Front � End</span></a><span style='mso-fareast-font-family:"Times New Roman";
font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></h1>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-variant:small-caps;
text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<p class=MsoNormal align=center style='margin-left:21.3pt;text-align:center;
page-break-after:avoid'><span style='font-variant:small-caps;text-transform:
uppercase;mso-no-proof:yes'><img border=0 width=639 height=477 id="_x0000_i1028"
src="effedoc_file/image034.png" alt="frontend_main.png"></span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoCaption align=center style='margin-left:21.3pt;text-align:center'><span
style='text-transform:uppercase'>Figura 7 - Home page<o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-variant:small-caps;
text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>Una volta
che l�utente esterno ha digitato l�url della web application nel proprio
browser, gli verr� presentata una schermata simile a quella di figura 6.</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>Principalmente
l�utente potr�:</span><span style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>1.</span></i><i><span style='font-size:7.0pt;line-height:115%;
font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></i><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Aprire un nuovo Documento</span></i><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>2.</span></i><i><span style='font-size:7.0pt;line-height:115%;
font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></i><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Accedere alla Knowledgebase (FAQ)</span></i><span style='font-variant:
small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>3.</span></i><i><span style='font-size:7.0pt;line-height:115%;
font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></i><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Leggere gli Avvisi</span></i><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>4.</span></i><i><span style='font-size:7.0pt;line-height:115%;
font-family:"Times New Roman","serif";font-variant:small-caps;text-transform:
uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></i><i><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>Fare una ricerca tra le FAQ e gli Avvisi</span></i><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>&nbsp;</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>Il punto .2,
.3, e .4 non necessitano di approfondimento essendo di semplice consultazione.</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>Ci
concentreremo invece sulla procedura per l�apertura di un nuovo documento.<o:p></o:p></span></p>

<span style='font-size:11.0pt;line-height:115%;font-family:"Perpetua","serif";
mso-fareast-font-family:"Times New Roman";mso-fareast-theme-font:minor-fareast;
mso-bidi-font-family:"Times New Roman";font-variant:small-caps;color:black;
text-transform:uppercase;mso-ansi-language:IT;mso-fareast-language:IT;
mso-bidi-language:AR-SA'><br clear=all style='page-break-before:always'>
</span>

<p class=MsoNormal style='margin-left:21.3pt'><a name="_Toc248407512"><span
class=Titolo2Carattere><span style='font-size:12.0pt;line-height:115%;
font-variant:small-caps;text-transform:uppercase'>Apertura di un nuovo
documento</span></span></a><span style='font-variant:small-caps;text-transform:
uppercase'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-variant:small-caps;
text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>1.</span><span style='font-size:7.0pt;line-height:115%;font-family:
"Times New Roman","serif";font-variant:small-caps;text-transform:uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span><span style='font-size:12.0pt;line-height:115%;font-variant:small-caps;
text-transform:uppercase'>Dalla Home Page selezionare <b>Registra un Documento</b></span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>2.</span><span style='font-size:7.0pt;line-height:115%;font-family:
"Times New Roman","serif";font-variant:small-caps;text-transform:uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span><span style='font-size:12.0pt;line-height:115%;font-variant:small-caps;
text-transform:uppercase'>Selezionare il <b>Servizio</b> di interesse:</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph align=center style='margin-left:21.3pt;text-align:
center;page-break-after:avoid'><span style='font-variant:small-caps;text-transform:
uppercase;mso-no-proof:yes'><img border=0 width=559 height=295 id="_x0000_i1027"
src="effedoc_file/image035.png" alt="frontend_servizi.png"></span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoCaption align=center style='margin-left:21.3pt;text-align:center'><span
style='text-transform:uppercase'>Figura 8 - Selezionare l'area tematica<o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-variant:small-caps;
text-transform:uppercase'>&nbsp;<o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>3.</span><span style='font-size:7.0pt;line-height:115%;font-family:
"Times New Roman","serif";font-variant:small-caps;text-transform:uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span><span style='font-size:12.0pt;line-height:115%;font-variant:small-caps;
text-transform:uppercase'>Compilare la Form che viene presentata</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='margin-left:21.3pt;text-align:center;
page-break-after:avoid'><span style='font-variant:small-caps;text-transform:
uppercase;mso-no-proof:yes'><img border=0 width=557 height=367 id="_x0000_i1026"
src="effedoc_file/image036.png" alt="frontend_proto.png"></span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoCaption align=center style='margin-left:21.3pt;text-align:center'><span
style='text-transform:uppercase'>Figura 9 - Form dati<o:p></o:p></span></p>

<p class=MsoNormal style='margin-left:21.3pt'><span style='font-size:12.0pt;
line-height:115%;font-variant:small-caps;text-transform:uppercase'>&nbsp;</span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoListParagraph style='margin-left:53.4pt;text-indent:-18.0pt'><span
style='font-size:12.0pt;line-height:115%;font-variant:small-caps;text-transform:
uppercase'>4.</span><span style='font-size:7.0pt;line-height:115%;font-family:
"Times New Roman","serif";font-variant:small-caps;text-transform:uppercase'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span><span style='font-size:12.0pt;line-height:115%;font-variant:small-caps;
text-transform:uppercase'>Prendere nota del <b>numero di protocollo</b> o
stampare il relativo codice a barre</span><span style='font-variant:small-caps;
text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='margin-left:21.3pt;text-align:center;
page-break-after:avoid'><span style='font-variant:small-caps;text-transform:
uppercase;mso-no-proof:yes'><img border=0 width=637 height=378 id="_x0000_i1025"
src="effedoc_file/image037.png" alt="frontend_proto_result.png"></span><span
style='font-variant:small-caps;text-transform:uppercase'><o:p></o:p></span></p>

<p class=MsoCaption align=center style='margin-left:21.3pt;text-align:center'><span
style='text-transform:uppercase'>Figura 10 - numero di protocollo<o:p></o:p></span></p>

</span></div>

</body>

</html>
